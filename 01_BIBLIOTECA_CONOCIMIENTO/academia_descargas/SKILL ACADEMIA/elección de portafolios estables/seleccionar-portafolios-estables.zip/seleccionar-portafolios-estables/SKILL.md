---
name: seleccionar-portafolios-estables
description: Audita reportes individuales de StrategyQuant X, históricos o CSV de operaciones y portafolios de QuantAnalyzer para seleccionar combinaciones de estrategias con prioridad en estabilidad, suficiencia de muestra, OOS, estancamiento, rolling returns, linealidad y correlación, no en crecimiento explosivo. Usar cuando el usuario adjunte PDFs SQX, exports de QuantAnalyzer/MT4/MT5, matrices mensuales, CSV de trades o capturas de equity/drawdown y solicite filtrar estrategias, construir cestas, comparar combinaciones, explicar descartes, producir un top 3 estable o generar un informe PDF de selección de portafolio.
---

# Seleccionar portafolios estables

Seleccionar estrategias mediante un flujo reproducible y crítico. Priorizar estabilidad temporal y evidencia OOS; tratar retorno y Sharpe como métricas secundarias. No aceptar la portada de QuantAnalyzer como validación suficiente.

## Flujo obligatorio

### 1. Inventariar los insumos

Identificar para cada archivo:

- estrategia, activo, timeframe, dirección y tipo de orden;
- periodo, bróker/datos, capital, lotaje, costes y moneda;
- trades, PF, Sharpe, Return/DD, drawdown, average trade y estancamiento;
- delimitación IS/OOS y número de trades de cada muestra;
- formato disponible: PDF, HTML, CSV, XLSX o captura.

Solicitar únicamente lo indispensable que falte. Nunca asumir que dos reportes usan el mismo histórico, bróker, capital o sizing.

### 2. Ejecutar Gate 0: integridad y comparabilidad

Detener la aprobación y marcar `NO COMPARABLE` si existen diferencias materiales no normalizadas en:

- fechas o zona horaria;
- símbolo, bróker, spread, comisión o swap;
- capital inicial, lotaje o gestión monetaria;
- modo de simulación o calidad de datos;
- definición de IS/OOS;
- balance frente a equity flotante.

Detectar duplicados, tickets repetidos, métricas incompatibles y campos inválidos. QuantAnalyzer y SQX pueden calcular Sharpe, exposición y drawdown con metodologías distintas; reportar la discrepancia en vez de mezclar valores.

### 3. Normalizar los datos

Construir:

1. tabla maestra por estrategia;
2. matriz de PnL mensual alineada por calendario;
3. serie de trades o equity diaria cuando esté disponible;
4. tabla de metadatos y calidad.

Leer [references/entradas-y-salida.md](references/entradas-y-salida.md) para los esquemas. Usar `scripts/rank_stable_portfolios.py` cuando la matriz mensual y los metadatos estén normalizados.

### 4. Prefiltrar estrategias

Aplicar por defecto el perfil `stability-first`:

- trades completos por estrategia >= 200;
- PF >= 1,25; preferir >= 1,30;
- Sharpe comparable >= 0,80;
- estancamiento individual <= 650 días; tolerancia de revisión hasta 700;
- OOS 30%-40% cuando exista;
- OOS positivo y sin deterioro estructural;
- resultado reciente no dependiente de un único mes;
- average trade suficiente para costes adversos;
- excluir o poner en observación estrategias con estancamiento actual prolongado.

No bajar umbrales silenciosamente. Si la muestra no permite aprobar ninguna estrategia, devolver `SIN CANDIDATOS APROBADOS`.

### 5. Auditar correlación y concentración

Calcular Pearson sobre PnL mensual común y mostrar:

- matriz completa;
- media, mediana, mínimo y máximo;
- porcentaje de pares con |r| <= 0,10, 0,20 y 0,30;
- número efectivo de estrategias por eigenvalores;
- correlación por activo, dirección y familia;
- contribución al riesgo por estrategia y por factor.

No inferir correlación alta solo porque varias estrategias usan el mismo activo. Tampoco llamar diversificado a un portafolio solo porque la correlación media sea baja: medir concentración por factor.

### 6. Enumerar combinaciones con estabilidad primero

Exigir por defecto para cada portafolio candidato:

- trades agregados >= 2.500;
- al menos dos activos o factores, salvo justificación cuantitativa;
- todos los años completos positivos;
- rolling 24 meses mínimo > 0;
- rolling 12 meses positivo en 100% de las ventanas para el perfil estricto;
- resultado OOS y reciente > 0;
- estancamiento mensual máximo <= 8 meses;
- estancamiento mensual actual <= 3 meses;
- máxima correlación mensual <= 0,50; preferir <= 0,30;
- ausencia de dependencia excesiva de un año o una estrategia.

Usar la puntuación base descrita en [references/metricas-y-gates.md](references/metricas-y-gates.md). El retorno absoluto no forma parte del núcleo del score.

### 7. Construir un top 3 no cosmético

Entregar tres soluciones con función distinta:

1. `Balance Core`: mejor estabilidad integral;
2. `Linear Stability`: mayor linealidad y mejor peor periodo;
3. `Large Sample Stability`: mayor muestra conservando los gates.

Evitar tres cestas casi idénticas sin explicar la diferencia. Si la frontera eficiente solo produce una cesta válida, entregar una y declarar que no existen tres opciones aprobadas.

### 8. Validar en QuantAnalyzer

Esta comprobación prevalece sobre el modelo mensual.

Solicitar o revisar para cada finalista:

- `Direction: L+S` para el portafolio total;
- `X Axis: Time` para medir estancamiento temporal;
- curvas `Full`, `IS` y `OOS` por separado;
- vista `Long` y `Short` solo como diagnóstico adicional;
- equity, drawdown, lista de trades y estadísticas exportadas;
- drawdown de equity flotante cuando sea posible.

No atribuir al portafolio total una captura con `Lng` o `Shr` seleccionado. No confundir el número de puntos de la gráfica con trades sin verificarlo.

Rechazar o devolver a revisión si:

- estancamiento real máximo >= 365 días para perfil estricto;
- estancamiento actual >= 90 días;
- OOS es negativo, plano o recuperado principalmente después del OOS;
- OOS agregado < 30% del total o tiene muestra insuficiente;
- la curva depende de pocos trades o de un tramo final explosivo;
- el DD real excede claramente el estimado mensual.

### 9. Emitir el dictamen

Presentar, en este orden:

1. auditoría de insumos y limitaciones;
2. estrategias excluidas con motivo cuantitativo;
3. correlación y concentración;
4. top 3 con composición exacta;
5. tabla comparativa de estabilidad;
6. OOS y suficiencia de muestra;
7. comprobación QuantAnalyzer;
8. dictamen `APROBADO`, `APROBADO PARA INCUBACIÓN`, `REVISIÓN` o `RECHAZADO`;
9. siguiente evidencia necesaria.

Incluir como mínimo: trades, PF combinado, Sharpe mensual anualizado, meses positivos, R², MDD, peor mes, mínimo rolling 12/24 meses, años negativos, correlación media/máxima, número efectivo, OOS/pre-OOS, estancamiento máximo y actual.

Crear PDF únicamente si el usuario lo solicita. Aplicar la habilidad PDF y verificar visualmente todas las páginas antes de entregarlo.

## Principios de independencia

- Recalcular antes de aceptar métricas del software.
- Corregir conclusiones previas cuando los datos las contradigan.
- Separar hechos, estimaciones y proxies.
- No transformar una muestra insuficiente en aprobada mediante un score atractivo.
- No recomendar una cesta que incumpla el objetivo declarado aunque maximice retorno.
- Mostrar siempre qué información falta para medir estancamiento y OOS de forma real.
