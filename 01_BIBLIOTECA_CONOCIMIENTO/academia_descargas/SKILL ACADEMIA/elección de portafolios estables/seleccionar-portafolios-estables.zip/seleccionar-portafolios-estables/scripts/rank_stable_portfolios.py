#!/usr/bin/env python3
"""Rank equal-risk strategy combinations with a stability-first objective.

The script is a pre-selection engine. Monthly results cannot replace the final
trade/time validation in QuantAnalyzer, especially for drawdown and stagnation.
"""

from __future__ import annotations

import argparse
import itertools
import json
import math
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd


REQUIRED_METADATA = {
    "strategy",
    "symbol",
    "trades",
    "profit_factor",
    "sharpe",
    "stagnation_days",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Enumerate and rank strategy portfolios using sample, rolling-return, "
            "linearity, correlation and stagnation gates."
        )
    )
    parser.add_argument("--monthly", required=True, type=Path, help="Wide monthly PnL CSV")
    parser.add_argument("--metadata", required=True, type=Path, help="Strategy metadata CSV")
    parser.add_argument("--output", required=True, type=Path, help="Ranked candidates CSV")
    parser.add_argument("--summary", type=Path, help="Optional JSON audit summary")
    parser.add_argument("--min-size", type=int, default=4)
    parser.add_argument("--max-size", type=int, default=12)
    parser.add_argument("--min-total-trades", type=int, default=2500)
    parser.add_argument("--min-individual-trades", type=int, default=200)
    parser.add_argument("--min-pf", type=float, default=1.25)
    parser.add_argument("--min-sharpe", type=float, default=0.80)
    parser.add_argument("--max-individual-stagnation-days", type=float, default=700)
    parser.add_argument("--min-symbols", type=int, default=2)
    parser.add_argument("--max-positive-correlation", type=float, default=0.50)
    parser.add_argument("--max-monthly-stagnation", type=int, default=8)
    parser.add_argument("--max-current-stagnation", type=int, default=3)
    parser.add_argument(
        "--max-individual-current-stagnation",
        type=int,
        default=3,
        help="Maximum current monthly stagnation allowed for an individual strategy",
    )
    parser.add_argument("--min-oos-share", type=float, default=0.30)
    parser.add_argument("--oos-start", help="First OOS month, YYYY-MM-DD")
    parser.add_argument(
        "--recent-start",
        help="First recent-validation month; defaults to the last 12 observations",
    )
    parser.add_argument("--top", type=int, default=50)
    parser.add_argument("--max-combinations", type=int, default=2_000_000)
    return parser.parse_args()


def require_columns(frame: pd.DataFrame, required: Iterable[str], source: str) -> None:
    missing = sorted(set(required) - set(frame.columns))
    if missing:
        raise ValueError(f"{source} is missing required columns: {', '.join(missing)}")


def load_monthly(path: Path) -> pd.DataFrame:
    frame = pd.read_csv(path)
    require_columns(frame, ["date"], str(path))
    frame["date"] = pd.to_datetime(frame["date"], errors="coerce")
    if frame["date"].isna().any():
        raise ValueError("Monthly CSV contains invalid dates")
    if frame["date"].duplicated().any():
        raise ValueError("Monthly CSV contains duplicate dates")
    frame = frame.sort_values("date").set_index("date")
    if frame.empty or len(frame.columns) < 2:
        raise ValueError("Monthly CSV needs at least two strategy columns")
    frame = frame.apply(pd.to_numeric, errors="coerce")
    if frame.isna().any().any():
        bad = frame.columns[frame.isna().any()].tolist()
        raise ValueError(f"Monthly CSV has missing/non-numeric values in: {', '.join(bad)}")
    if not frame.index.to_period("M").is_unique:
        raise ValueError("Monthly CSV must have one row per calendar month")
    return frame.astype(float)


def load_metadata(path: Path, monthly_columns: Iterable[str]) -> pd.DataFrame:
    frame = pd.read_csv(path)
    require_columns(frame, REQUIRED_METADATA, str(path))
    if frame["strategy"].duplicated().any():
        dup = frame.loc[frame["strategy"].duplicated(), "strategy"].tolist()
        raise ValueError(f"Metadata has duplicate strategies: {', '.join(map(str, dup))}")
    frame["strategy"] = frame["strategy"].astype(str)
    frame["symbol"] = frame["symbol"].astype(str)
    for column in ["trades", "profit_factor", "sharpe", "stagnation_days"]:
        frame[column] = pd.to_numeric(frame[column], errors="coerce")
    if frame[["trades", "profit_factor", "sharpe", "stagnation_days"]].isna().any().any():
        raise ValueError("Metadata contains invalid numeric gate values")
    missing = sorted(set(monthly_columns) - set(frame["strategy"]))
    if missing:
        raise ValueError(f"Metadata is missing monthly strategies: {', '.join(missing)}")
    if "oos_trades" in frame.columns:
        frame["oos_trades"] = pd.to_numeric(frame["oos_trades"], errors="coerce")
        if frame["oos_trades"].isna().any():
            raise ValueError("Metadata contains invalid oos_trades values")
    return frame.set_index("strategy").loc[list(monthly_columns)]


def stagnation_months(profit: pd.Series) -> tuple[int, int]:
    equity = profit.cumsum().to_numpy(dtype=float)
    peak = 0.0
    current = 0
    maximum = 0
    for value in equity:
        if value > peak + 1e-12:
            peak = value
            current = 0
        else:
            current += 1
            maximum = max(maximum, current)
    return maximum, current


def effective_number(correlation: pd.DataFrame) -> float:
    matrix = correlation.to_numpy(dtype=float)
    matrix = np.nan_to_num(matrix, nan=0.0, posinf=0.0, neginf=0.0)
    np.fill_diagonal(matrix, 1.0)
    eigenvalues = np.linalg.eigvalsh(matrix)
    eigenvalues = np.clip(eigenvalues, 0.0, None)
    denominator = float(np.square(eigenvalues).sum())
    return float(np.square(eigenvalues.sum()) / denominator) if denominator > 0 else math.nan


def complete_years(profit: pd.Series) -> pd.Series:
    table = pd.DataFrame({"profit": profit, "year": profit.index.year})
    grouped = table.groupby("year")["profit"].agg(["sum", "count"])
    return grouped.loc[grouped["count"] == 12, "sum"]


def portfolio_metrics(
    selected: tuple[str, ...],
    monthly: pd.DataFrame,
    metadata: pd.DataFrame,
    recent_start: pd.Timestamp | None,
    oos_start: pd.Timestamp | None,
) -> dict[str, object]:
    values = monthly.loc[:, list(selected)]
    profit = values.sum(axis=1)
    equity = profit.cumsum()
    time = np.arange(len(equity), dtype=float)
    r2 = float(np.corrcoef(time, equity.to_numpy(dtype=float))[0, 1] ** 2) if len(equity) > 1 else math.nan

    drawdown = equity - equity.cummax().clip(lower=0.0)
    annual = complete_years(profit)
    rolling_12 = profit.rolling(12).sum().dropna()
    rolling_24 = profit.rolling(24).sum().dropna()
    max_stag, current_stag = stagnation_months(profit)

    volatility = float(profit.std(ddof=1))
    sharpe = float((profit.mean() / volatility) * math.sqrt(12)) if volatility > 0 else math.nan
    annual_mean = float(annual.mean()) if not annual.empty else math.nan
    annual_cv = (
        float(annual.std(ddof=0) / abs(annual_mean))
        if len(annual) > 1 and abs(annual_mean) > 1e-12
        else math.nan
    )
    min_year = float(annual.min()) if not annual.empty else math.nan
    min_year_ratio = min_year / annual_mean if annual_mean > 0 else math.nan

    corr = values.corr()
    upper = corr.to_numpy(dtype=float)[np.triu_indices(len(selected), k=1)]
    upper = upper[np.isfinite(upper)]
    average_corr = float(upper.mean()) if len(upper) else math.nan
    maximum_corr = float(upper.max()) if len(upper) else math.nan
    maximum_abs_corr = float(np.abs(upper).max()) if len(upper) else math.nan

    subset = metadata.loc[list(selected)]
    total_trades = int(round(float(subset["trades"].sum())))
    oos_trades = float(subset["oos_trades"].sum()) if "oos_trades" in subset.columns else math.nan
    oos_share = oos_trades / total_trades if total_trades > 0 and math.isfinite(oos_trades) else math.nan

    if recent_start is None:
        recent = profit.tail(min(12, len(profit)))
    else:
        recent = profit.loc[profit.index >= recent_start]
    recent_profit = float(recent.sum()) if len(recent) else math.nan

    pre_oos_profit = math.nan
    oos_profit = math.nan
    oos_retention = math.nan
    oos_months = 0
    if oos_start is not None:
        pre = profit.loc[profit.index < oos_start]
        oos = profit.loc[profit.index >= oos_start]
        oos_months = len(oos)
        if len(pre) and len(oos):
            pre_oos_profit = float(pre.sum())
            oos_profit = float(oos.sum())
            pre_annualized = pre.mean() * 12
            oos_annualized = oos.mean() * 12
            if abs(pre_annualized) > 1e-12:
                oos_retention = float(oos_annualized / pre_annualized)

    symbols = subset["symbol"].nunique()
    symbol_counts = subset["symbol"].value_counts(normalize=True)

    return {
        "strategies": " | ".join(selected),
        "size": len(selected),
        "symbols": int(symbols),
        "max_symbol_share": float(symbol_counts.iloc[0]),
        "total_trades": total_trades,
        "oos_trades": oos_trades,
        "oos_share": oos_share,
        "profit": float(profit.sum()),
        "sharpe_monthly_ann": sharpe,
        "positive_months_pct": float((profit > 0).mean()),
        "r2_equity": r2,
        "monthly_mdd_abs": float(-drawdown.min()),
        "worst_month": float(profit.min()),
        "complete_years": int(len(annual)),
        "negative_complete_years": int((annual <= 0).sum()),
        "min_complete_year": min_year,
        "min_year_ratio": min_year_ratio,
        "annual_cv": annual_cv,
        "rolling_12_min": float(rolling_12.min()) if len(rolling_12) else math.nan,
        "rolling_12_positive_pct": float((rolling_12 > 0).mean()) if len(rolling_12) else math.nan,
        "rolling_24_min": float(rolling_24.min()) if len(rolling_24) else math.nan,
        "rolling_24_positive_pct": float((rolling_24 > 0).mean()) if len(rolling_24) else math.nan,
        "max_stagnation_months": max_stag,
        "current_stagnation_months": current_stag,
        "recent_profit": recent_profit,
        "pre_oos_profit": pre_oos_profit,
        "oos_profit": oos_profit,
        "oos_months": oos_months,
        "oos_retention": oos_retention,
        "average_correlation": average_corr,
        "maximum_positive_correlation": maximum_corr,
        "maximum_absolute_correlation": maximum_abs_corr,
        "effective_strategies": effective_number(corr),
        "average_individual_stagnation_days": float(subset["stagnation_days"].mean()),
        "maximum_individual_stagnation_days": float(subset["stagnation_days"].max()),
    }


def percentile(frame: pd.DataFrame, column: str, higher_is_better: bool = True) -> pd.Series:
    values = frame[column].replace([np.inf, -np.inf], np.nan)
    if values.notna().sum() == 0:
        return pd.Series(0.5, index=frame.index)
    filled = values.fillna(values.median())
    ranked = filled.rank(method="average", pct=True, ascending=higher_is_better)
    return ranked


def add_score(frame: pd.DataFrame) -> pd.DataFrame:
    scored = frame.copy()
    scored["stability_score"] = (
        percentile(scored, "r2_equity") * 0.22
        + percentile(scored, "positive_months_pct") * 0.10
        + percentile(scored, "rolling_12_positive_pct") * 0.15
        + percentile(scored, "min_year_ratio") * 0.15
        + percentile(scored, "rolling_12_min") * 0.10
        + percentile(scored, "rolling_24_min") * 0.08
        + percentile(scored, "sharpe_monthly_ann") * 0.07
        + percentile(scored, "total_trades") * 0.08
        + percentile(scored, "oos_retention") * 0.05
        - percentile(scored, "annual_cv") * 0.12
        - percentile(scored, "average_individual_stagnation_days") * 0.06
        - scored["maximum_positive_correlation"].clip(lower=0).fillna(0) * 0.02
    )
    return scored.sort_values(
        ["stability_score", "r2_equity", "min_year_ratio", "total_trades"],
        ascending=[False, False, False, False],
    ).reset_index(drop=True)


def count_combinations(pool_size: int, min_size: int, max_size: int) -> int:
    return sum(math.comb(pool_size, size) for size in range(min_size, max_size + 1))


def main() -> int:
    args = parse_args()
    monthly = load_monthly(args.monthly)
    metadata = load_metadata(args.metadata, monthly.columns)

    individual_current = {column: stagnation_months(monthly[column])[1] for column in monthly.columns}
    base_gate = (
        (metadata["trades"] >= args.min_individual_trades)
        & (metadata["profit_factor"] >= args.min_pf)
        & (metadata["sharpe"] >= args.min_sharpe)
        & (metadata["stagnation_days"] <= args.max_individual_stagnation_days)
    )
    eligible = [
        strategy
        for strategy in monthly.columns
        if bool(base_gate.loc[strategy])
        and individual_current[strategy] <= args.max_individual_current_stagnation
    ]
    excluded = {
        strategy: {
            "trades": float(metadata.loc[strategy, "trades"]),
            "profit_factor": float(metadata.loc[strategy, "profit_factor"]),
            "sharpe": float(metadata.loc[strategy, "sharpe"]),
            "stagnation_days": float(metadata.loc[strategy, "stagnation_days"]),
            "current_stagnation_months": individual_current[strategy],
        }
        for strategy in monthly.columns
        if strategy not in eligible
    }

    if len(eligible) < args.min_size:
        raise ValueError(
            f"Only {len(eligible)} strategies pass individual gates; need {args.min_size}. "
            "Do not lower thresholds silently."
        )
    max_size = min(args.max_size, len(eligible))
    total_combinations = count_combinations(len(eligible), args.min_size, max_size)
    if total_combinations > args.max_combinations:
        raise ValueError(
            f"Requested search has {total_combinations:,} combinations, above "
            f"--max-combinations={args.max_combinations:,}. Narrow the eligible pool or sizes."
        )

    recent_start = pd.Timestamp(args.recent_start) if args.recent_start else None
    oos_start = pd.Timestamp(args.oos_start) if args.oos_start else None
    rows: list[dict[str, object]] = []
    gate_rejections: dict[str, int] = {
        "sample": 0,
        "symbols": 0,
        "complete_year": 0,
        "rolling_12": 0,
        "rolling_24": 0,
        "recent": 0,
        "oos": 0,
        "stagnation": 0,
        "correlation": 0,
    }

    for size in range(args.min_size, max_size + 1):
        for selected in itertools.combinations(eligible, size):
            row = portfolio_metrics(selected, monthly, metadata, recent_start, oos_start)
            if row["total_trades"] < args.min_total_trades:
                gate_rejections["sample"] += 1
                continue
            if row["symbols"] < args.min_symbols:
                gate_rejections["symbols"] += 1
                continue
            if row["complete_years"] < 1 or row["negative_complete_years"] > 0:
                gate_rejections["complete_year"] += 1
                continue
            if not math.isfinite(float(row["rolling_12_min"])) or float(row["rolling_12_min"]) <= 0:
                gate_rejections["rolling_12"] += 1
                continue
            if float(row["rolling_12_positive_pct"]) < 1.0:
                gate_rejections["rolling_12"] += 1
                continue
            if not math.isfinite(float(row["rolling_24_min"])) or float(row["rolling_24_min"]) <= 0:
                gate_rejections["rolling_24"] += 1
                continue
            if not math.isfinite(float(row["recent_profit"])) or float(row["recent_profit"]) <= 0:
                gate_rejections["recent"] += 1
                continue
            if oos_start is not None and (
                int(row["oos_months"]) < 12
                or not math.isfinite(float(row["oos_profit"]))
                or float(row["oos_profit"]) <= 0
            ):
                gate_rejections["oos"] += 1
                continue
            if "oos_trades" in metadata.columns and (
                not math.isfinite(float(row["oos_share"]))
                or float(row["oos_share"]) < args.min_oos_share
            ):
                gate_rejections["oos"] += 1
                continue
            if (
                int(row["max_stagnation_months"]) > args.max_monthly_stagnation
                or int(row["current_stagnation_months"]) > args.max_current_stagnation
            ):
                gate_rejections["stagnation"] += 1
                continue
            if (
                math.isfinite(float(row["maximum_positive_correlation"]))
                and float(row["maximum_positive_correlation"]) > args.max_positive_correlation
            ):
                gate_rejections["correlation"] += 1
                continue
            rows.append(row)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    if rows:
        ranked = add_score(pd.DataFrame(rows))
        ranked.insert(0, "rank", np.arange(1, len(ranked) + 1))
        ranked.head(args.top).to_csv(args.output, index=False)
    else:
        ranked = pd.DataFrame()
        pd.DataFrame(columns=["rank", "strategies", "stability_score"]).to_csv(args.output, index=False)

    final_status = "PRESELECTED_FOR_QA_VALIDATION" if len(ranked) else "NO_APPROVED_CANDIDATES"
    if oos_start is None or "oos_trades" not in metadata.columns:
        final_status = "REVIEW_MISSING_OOS_EVIDENCE" if len(ranked) else final_status
    top_records = (
        json.loads(ranked.head(min(args.top, 10)).to_json(orient="records"))
        if len(ranked)
        else []
    )
    summary = {
        "status": final_status,
        "monthly_source": str(args.monthly),
        "metadata_source": str(args.metadata),
        "parameters": {
            "min_size": args.min_size,
            "max_size": max_size,
            "min_total_trades": args.min_total_trades,
            "min_individual_trades": args.min_individual_trades,
            "min_pf": args.min_pf,
            "min_sharpe": args.min_sharpe,
            "max_individual_stagnation_days": args.max_individual_stagnation_days,
            "max_individual_current_stagnation": args.max_individual_current_stagnation,
            "max_monthly_stagnation": args.max_monthly_stagnation,
            "max_current_stagnation": args.max_current_stagnation,
            "max_positive_correlation": args.max_positive_correlation,
            "min_oos_share": args.min_oos_share,
            "oos_start": args.oos_start,
            "recent_start": args.recent_start,
        },
        "eligible_strategies": eligible,
        "excluded_strategies": excluded,
        "combinations_evaluated": total_combinations,
        "candidates_after_gates": int(len(ranked)),
        "gate_rejections": gate_rejections,
        "top_candidates": top_records,
        "warnings": [
            "Monthly stagnation and drawdown are pre-filters; validate L+S with X Axis: Time.",
            "Use equal-risk or otherwise normalized strategy PnL before comparing combinations.",
            "Do not approve without a sealed, sufficiently large OOS sample.",
        ],
    }
    if args.summary:
        args.summary.parent.mkdir(parents=True, exist_ok=True)
        args.summary.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")

    print(json.dumps(summary, indent=2, ensure_ascii=False))
    if len(ranked):
        columns = [
            "rank",
            "strategies",
            "stability_score",
            "total_trades",
            "r2_equity",
            "rolling_12_min",
            "rolling_24_min",
            "max_stagnation_months",
            "current_stagnation_months",
            "maximum_positive_correlation",
            "effective_strategies",
        ]
        print(ranked.head(min(args.top, 10))[columns].to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
