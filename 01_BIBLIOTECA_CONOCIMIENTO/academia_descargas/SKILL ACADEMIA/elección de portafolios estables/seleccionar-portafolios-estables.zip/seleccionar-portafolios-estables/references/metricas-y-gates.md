# Métricas y gates de estabilidad

## Índice

1. Definiciones
2. Gates por defecto
3. Score stability-first
4. Criterios OOS
5. Alertas de interpretación

## 1. Definiciones

### Muestra

- `Trades completos`: operaciones cerradas de toda la muestra.
- `Trades OOS`: operaciones cuya entrada pertenece al periodo OOS sellado.
- `OOS %`: trades OOS / trades completos.
- No usar barras, puntos de una curva o tickets cancelados como trades cerrados.

### Estabilidad temporal

- `Meses positivos`: proporción de meses con PnL > 0.
- `Rolling 12/24 mínimo`: menor suma de PnL en cualquier ventana consecutiva de 12/24 meses.
- `R²`: correlación al cuadrado entre tiempo y equity acumulada mensual. Usar como linealidad, no como prueba de robustez.
- `CV anual`: desviación estándar de resultados anuales / media anual. Menor es mejor.
- `Min-year ratio`: peor año completo / media de años completos. Mayor es mejor.

### Estancamiento

- `Estancamiento máximo`: mayor tiempo entre un máximo de equity y su recuperación.
- `Estancamiento actual`: tiempo desde el último máximo hasta el final de la muestra.
- Calcular por tiempo con datos diarios/trades. La versión mensual es solo un pre-filtro y puede ocultar cientos de días.

### OOS retention

`OOS retention = beneficio anualizado OOS / beneficio anualizado pre-OOS`.

- 0,80-1,20: estable.
- 0,50-0,80: deterioro moderado.
- <0,50 o negativo: falla.
- >1,50: revisar dependencia de pocos trades o cambio de régimen favorable.

### Número efectivo

Para matriz de correlación `C` con eigenvalores `lambda`:

`N_eff = (sum(lambda))² / sum(lambda²)`.

Comparar `N_eff` con el número nominal de estrategias.

## 2. Gates por defecto

| Gate | Estricto | Revisión |
|---|---:|---:|
| Trades por estrategia | >=200 | >=150 |
| Trades portafolio | >=2.500 | >=1.500 |
| OOS | 30%-40% | >=20% |
| PF individual | >=1,30 | >=1,25 |
| Sharpe comparable | >=0,80 | >=0,60 |
| Stagnation individual | <=650 d | <=700 d |
| Stagnation portafolio | <365 d | <550 d |
| Stagnation actual | <90 d | <180 d |
| Rolling 24 mínimo | >0 | informar |
| Años completos negativos | 0 | máximo 1 justificado |
| Máxima correlación mensual | <=0,30 preferida | <=0,50 |

No convertir los valores de revisión en aprobación automática.

## 3. Score stability-first

Calcular percentiles entre candidatos que ya superaron gates:

| Componente | Peso |
|---|---:|
| R² equity mensual | 0,22 |
| Meses positivos | 0,10 |
| Rolling 12 positivos | 0,15 |
| Min-year ratio | 0,15 |
| Rolling 12 mínimo | 0,10 |
| Rolling 24 mínimo | 0,08 |
| Sharpe mensual anualizado | 0,07 |
| Trades agregados | 0,08 |
| OOS retention | 0,05 |

Penalizaciones:

- percentil de CV anual × 0,12;
- percentil de estancamiento individual medio × 0,06;
- `max(0, correlación máxima) × 0,02`.

No incluir retorno absoluto como componente central. Usarlo para desempatar solo después de estabilidad, muestra y OOS.

## 4. Criterios OOS

Separar:

- IS de construcción;
- OOS sellado;
- validación posterior o incubación.

Medir en OOS:

- trades y porcentaje de muestra;
- PnL, PF, Sharpe y DD;
- estancamiento máximo y actual;
- rolling 6/12 meses;
- aporte por estrategia;
- dependencia del mejor trade/mes;
- OOS retention.

Una curva que cae o permanece plana dentro del OOS y recupera después no aprueba OOS.

## 5. Alertas de interpretación

- `Direction: Lng` no representa L+S.
- `X Axis: Trade` no mide duración temporal del estancamiento.
- El DD mensual suele subestimar el DD intrames y flotante.
- Correlación baja no elimina concentración por JPY, USD, oro, índices o una misma familia lógica.
- Sumar trades individuales no sustituye el conteo OOS real.
- Un score alto no rescata una muestra insuficiente.
