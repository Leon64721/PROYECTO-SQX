# Entradas normalizadas y salida

## Entradas aceptadas

Priorizar, de mayor a menor capacidad de auditoría:

1. CSV de trades por estrategia;
2. export de QuantAnalyzer;
3. HTML MT4/MT5;
4. PDF SQX individual;
5. capturas de QuantAnalyzer.

Las capturas sirven para validar configuración visual, forma de curva y estancamiento mostrado; no sustituyen el export numérico.

## Matriz mensual

CSV ancho para `rank_stable_portfolios.py`:

```csv
date,EA_01,EA_02,EA_03
2019-01-01,12.5,-3.1,4.2
2019-02-01,-2.0,7.4,0.0
```

Reglas:

- una fila por mes común;
- fechas ISO `YYYY-MM-DD`;
- PnL neto en una moneda común;
- PnL previamente normalizado a igual riesgo o a un sizing comparable;
- incluir cero únicamente si la estrategia estuvo activa y no operó;
- dejar vacío si falta información; no convertir faltantes en cero.

## Metadatos

CSV:

```csv
strategy,symbol,direction,trades,profit_factor,sharpe,stagnation_days
EA_01,USDJPY,LONG,310,1.44,0.98,420
EA_02,EURJPY,SHORT,260,1.51,1.02,380
```

Columnas obligatorias para el script: `strategy`, `symbol`, `trades`, `profit_factor`, `sharpe`, `stagnation_days`. Recomendadas para la auditoría: `direction`, `broker`, `timeframe`, `is_trades`, `oos_trades`.

## Ejecución reproducible

```bash
python3 scripts/rank_stable_portfolios.py \
  --monthly pnl_mensual.csv \
  --metadata estrategias.csv \
  --output candidatos.csv \
  --summary auditoria.json \
  --oos-start 2023-01-01
```

No omitir `--oos-start` si existe una división OOS sellada. Si falta `oos_trades`, el motor puede preseleccionar, pero devolverá estado de revisión por evidencia OOS incompleta.

## Salidas del script

- CSV de candidatos ordenados;
- JSON con parámetros, gates y top;
- consola con top resumido.

El análisis final debe añadir la comprobación de QuantAnalyzer por tiempo y L+S; el script no puede validar estancamiento diario ni equity flotante a partir de datos mensuales.

## Tabla mínima del informe

| Campo | Obligatorio |
|---|---|
| Estrategias exactas | Sí |
| Trades full/OOS | Sí |
| PF y Sharpe | Sí |
| Meses positivos | Sí |
| R² | Sí |
| Rolling 12/24 mínimo | Sí |
| MDD balance/equity | Sí |
| Stagnation máximo/actual | Sí |
| Correlación media/máxima | Sí |
| N efectivo | Sí |
| OOS retention | Sí |
| Estrategias excluidas | Sí |
| Limitaciones | Sí |
