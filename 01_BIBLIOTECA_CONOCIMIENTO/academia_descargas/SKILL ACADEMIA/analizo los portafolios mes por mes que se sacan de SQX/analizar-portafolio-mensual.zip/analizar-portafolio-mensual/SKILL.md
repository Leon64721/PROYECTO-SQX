---
name: analizar-portafolio-mensual
description: Analiza mensualmente un portafolio algorítmico en incubación comparando un backtest o export de QuantAnalyzer con el historial real de MT5 y, cuando exista, una cuenta o captura de Myfxbook. Usar cuando el usuario adjunte CSV de operaciones, ReportHistory HTML de MT5, métricas o enlace de Myfxbook y solicite auditoría live-vs-backtest, paridad de ejecución, atribución por activo/EA, drawdown, gráficos comparativos, dictamen de incubación o reporte PDF mensual.
---

# Analizar portafolio mensual

Ejecutar un flujo cerrado y auditable. Priorizar consistencia de datos antes de interpretar rentabilidad. No declarar validado un edge con una muestra live pequeña.

## 1. Reunir los insumos

Solicitar solo lo que falte y sea material:

- Export de operaciones del backtest en CSV, preferiblemente QuantAnalyzer.
- `ReportHistory-*.html` exportado desde MT5 con posiciones, deals, resultados y posiciones abiertas.
- Enlace o captura de Myfxbook cuando se use como referencia auditada.
- Nombre del portafolio, balance inicial y fecha de corte si no pueden inferirse.
- Export del mes anterior solo cuando se necesite calcular el incremento mensual de un historial acumulado.

Leer [references/input-contract.md](references/input-contract.md) si los archivos no tienen el formato esperado, si hay varios balances o si debe reconstruirse un mes desde exports acumulados.

## 2. Ejecutar el control de datos

Antes del análisis:

1. Identificar moneda, broker, cuenta real/demo, balance inicial y periodo.
2. Contar posiciones cerradas, no filas de deals. Evitar doble conteo de entrada y salida.
3. Separar depósitos, retiros, créditos, comisión, swap y P/L de mercado.
4. Separar balance cerrado de equity y flotante abierto.
5. Verificar si una operación de P/L cero explica diferencias de conteo.
6. Comparar la suma del CSV con la cifra headline de Myfxbook o QuantAnalyzer.
7. Confirmar si `Comm/Swap` ya está incluido en `P/L in money`; presentar ambos escenarios si es ambiguo.
8. Revisar `Sample type`. Si todo aparece como IS, declararlo explícitamente: la incubación live será la principal evidencia OOS.
9. Verificar comparabilidad de sizing, lotes, costes, símbolo, broker y capital.

No continuar silenciosamente con datos incompatibles. Documentar diferencias y usar la base comparable más conservadora.

## 3. Calcular la base cuantitativa

Usar el motor incluido cuando los formatos sean compatibles:

```bash
python3 scripts/analyze_monthly_portfolio.py \
  --benchmark-csv /ruta/backtest.csv \
  --mt5-html /ruta/ReportHistory.html \
  --portfolio "Nombre del portafolio" \
  --starting-balance 10000 \
  --output-dir /ruta/salida
```

Opcionales:

- `--benchmark-json`: métricas visibles en Myfxbook/QuantAnalyzer que no existen en el CSV.
- `--mapping-json`: patrones de comentarios de EA a bloques o familias.
- `--previous-mt5-html`: export acumulado del corte anterior para aislar el mes nuevo.
- `--period-label`: etiqueta humana del periodo.

El script genera `analysis.json`, CSV normalizados y cinco gráficos PNG. Si falla por una variante del reporte, inspeccionar el HTML y adaptar una copia temporal del parser; no alterar el skill durante un reporte ordinario.

## 4. Comparar backtest y live

Incluir como mínimo:

- P/L y retorno sobre balance inicial.
- Profit factor, win rate, promedio por trade, gross profit y gross loss.
- Operaciones por mes y P/L mensual promedio histórico.
- Drawdown máximo de balance y de equity cuando esté disponible.
- Equity al corte con posiciones abiertas.
- Mayor ganancia/pérdida y rachas.
- Stagnation, Ret/DD, SQN, exposición y payout cuando la fuente los aporte.
- Paridad live/histórico para PF, win rate, promedio/trade, P/L mensual y frecuencia.

No mezclar magnitudes distintas en un mismo eje. Para la paridad usar un índice con benchmark = 100.

## 5. Atribuir resultados

Consolidar primero por símbolo. Luego consolidar por EA o familia usando el comentario de MT5.

- Mostrar trades, P/L, PF, win rate y promedio por bloque.
- Comparar cada bloque live con su contribución histórica mensual.
- Señalar concentración: un bloque puede rescatar el portafolio y ocultar deterioro en otro.
- No retirar un EA solo por un mes negativo. Exigir muestra suficiente y revisar señales/ejecución antes de intervenir.

## 6. Emitir el dictamen

Usar tres estados y explicar la evidencia:

- **APROBADO - continuar incubación:** ejecución coherente, PF acumulado normalmente >= 1,30, DD dentro del histórico y sin anomalías materiales.
- **VIGILAR:** PF 1,10-1,29, bloque importante con PF < 1, divergencias menores o DD acercándose al histórico.
- **CONGELAR Y AUDITAR:** errores sistemáticos, costes no modelados, DD por encima de la banda aceptada o PF < 1,10 después de una muestra relevante.

Los umbrales son valores iniciales, no leyes universales. Ajustarlos a los límites del usuario y al perfil del portafolio. Con menos de 100 trades, describir el dictamen como operativo/preliminar, no estadístico. No aumentar lotaje solo porque el primer mes supere la media.

Leer [references/report-standard.md](references/report-standard.md) antes de redactar el dictamen o generar el PDF.

## 7. Crear y verificar el PDF

Usar el skill de PDF. Crear un documento en español, A4, de 7 a 10 páginas con:

1. Portada, periodo y dictamen.
2. Resumen ejecutivo y tabla comparativa.
3. Índices de paridad.
4. Atribución por activo/EA.
5. Curva live de balance/equity y drawdown.
6. Contexto histórico anual y mensual.
7. Riesgos, costes y protocolo del siguiente mes.
8. Metodología, fuentes, limitaciones y controles realizados.

Renderizar todas las páginas a PNG e inspeccionarlas. Corregir textos cortados, tablas desbordadas, etiquetas ilegibles y contradicciones numéricas. Guardar el PDF final como archivo persistente y entregar un enlace.

## 8. Mantener continuidad mensual

Nombrar el archivo `Reporte_Incubacion_<Portafolio>_Mes_<NN>_<AAAA-MM>.pdf`.

En cada actualización:

- Conservar el benchmark congelado salvo que el usuario autorice reemplazarlo.
- Comparar acumulado live y solo el mes nuevo.
- Mantener gráficos, umbrales y definiciones estables.
- Registrar cambios de broker, lotaje, EAs o costes como ruptura de comparabilidad.
- No reescribir conclusiones históricas sin explicar el motivo.

## Prompt recomendado

```text
Usa $analizar-portafolio-mensual para auditar este portafolio en incubación. Compara el backtest con el export real de MT5 y la referencia de Myfxbook, valida la consistencia de los datos, analiza resultados por activo y EA, calcula paridad y drawdown, emite un dictamen crítico y crea el PDF mensual con gráficos. No aumentes el riesgo ni des por validado el edge si la muestra todavía es pequeña.
```
