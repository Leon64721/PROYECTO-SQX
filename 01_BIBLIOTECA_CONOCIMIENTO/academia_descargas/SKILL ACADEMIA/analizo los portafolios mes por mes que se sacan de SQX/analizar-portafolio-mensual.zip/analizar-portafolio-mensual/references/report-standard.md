# Estándar del reporte mensual

## Principio

Separar tres preguntas:

1. **¿La ejecución funciona?** Señales, lotes, símbolos, horarios y cierres.
2. **¿El resultado es compatible con el backtest?** Frecuencia, PF, win rate, payout, P/L y DD.
3. **¿Hay evidencia estadística suficiente?** Tamaño de muestra, OOS real, duración y regímenes.

Un mes puede aprobar la primera pregunta y seguir siendo insuficiente para la tercera.

## Métricas y fórmulas

- `P/L = suma del beneficio de posiciones cerradas + comisión + swap` solo si esos costes no están ya incorporados.
- `Return % = P/L / balance inicial * 100`.
- `PF = gross profit / abs(gross loss)`.
- `Win rate = ganadoras / operaciones no cero`.
- `Average trade = P/L / operaciones no cero`.
- `Balance DD = balance - máximo acumulado previo`.
- `Equity al corte = balance cerrado + flotante + swap abierto`.
- `Índice de paridad = métrica live / métrica histórica * 100` cuando el denominador sea positivo y comparable.

No derivar floating DD máximo de una lista de cierres. Si la fuente no lo contiene, marcarlo como no disponible.

## Gráficos obligatorios

1. Índice horizontal de paridad con línea benchmark = 100.
2. P/L live y promedio histórico mensual por bloque.
3. Balance live acumulado y drawdown de cierres.
4. P/L histórico anual.
5. Meses recientes del benchmark frente al periodo live.

Usar rojo solo para pérdidas o alertas, verde para resultado favorable, azul para histórico y dorado para benchmark/advertencia.

## Lectura de muestra

- `< 50 trades`: diagnóstico operativo, muy preliminar.
- `50-99`: evidencia inicial; evitar decisiones por un solo bloque.
- `100-199`: revisión intermedia; exigir paridad y control de DD.
- `>= 200`: permite una evaluación estadística más seria, siempre que abarque tiempo y regímenes suficientes.

El número de trades no sustituye la duración temporal.

## Dictamen

### APROBADO

- No hay fallos de ejecución.
- PF y promedio/trade son económicamente coherentes.
- Frecuencia no presenta desviación inexplicada.
- DD permanece dentro de la referencia.
- Costes live no invalidan el edge.

### VIGILAR

- Deterioro limitado o concentrado.
- Muestra pequeña con un bloque bajo presión.
- Diferencias de broker o costes todavía no resueltas.
- Drawdown se acerca a la referencia histórica.

### CONGELAR Y AUDITAR

- Trades faltantes/duplicados, lotaje incorrecto o cierre distinto.
- PF persistentemente bajo con muestra relevante.
- DD supera la banda autorizada.
- El portafolio live no coincide con el conjunto backtesteado.

## Contenido mínimo del PDF

- Fecha de corte y fuentes.
- Balance inicial, balance final y equity al corte.
- Tabla benchmark vs live.
- Atribución por símbolo y EA.
- Costes y diferencias de broker.
- Limitaciones: IS/OOS, muestra, balance DD vs equity DD.
- Decisión y acción concreta para el siguiente mes.

Evitar lenguaje promocional. Diferenciar hecho, cálculo e inferencia.
