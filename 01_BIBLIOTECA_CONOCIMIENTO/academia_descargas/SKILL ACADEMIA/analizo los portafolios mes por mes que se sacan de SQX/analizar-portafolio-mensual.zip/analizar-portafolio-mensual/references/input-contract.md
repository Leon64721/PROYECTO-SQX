# Contrato de insumos

## Archivos preferidos

### Backtest / QuantAnalyzer

CSV con, al menos:

- `Symbol`
- `Open time`
- `Close time`
- `P/L in money`

Campos útiles: `Ticket`, `Comm/Swap`, `Sample type`, `Size`, `Comment`, `P/L in %`.

### MT5

Export HTML de **Historial / Reporte**, no una captura parcial. Debe incluir:

- Positions cerradas.
- Deals.
- Open Positions.
- Results.

Leer HTML UTF-16 cuando corresponda. Contar la tabla Positions para operaciones; Deals contiene piernas de entrada/salida y puede duplicar el conteo.

### Myfxbook o resumen externo

Usar enlace, captura o JSON con estas claves cuando estén disponibles:

```json
{
  "headline_profit": 17698.52,
  "trades": 3419,
  "profit_factor": 1.39,
  "win_rate_pct": 44.36,
  "drawdown_money": 645.73,
  "drawdown_pct": 5.62,
  "return_dd": 27.41,
  "stagnation_days": 135,
  "sqn": 5.7,
  "payout_ratio": 1.74,
  "max_positions": 18,
  "max_lots": 2.04
}
```

No inventar claves ausentes.

## Exports acumulados

Si el MT5 actual contiene toda la vida de la cuenta y existe un export anterior:

1. Crear una clave estable por posición: `position_id` si existe; de lo contrario combinar fecha de apertura, símbolo, tipo, volumen y comentario.
2. Sustraer las posiciones ya presentes en el corte anterior.
3. Tratar cambios posteriores del broker o correcciones como discrepancias, no como trades nuevos.
4. Calcular por separado mes incremental y acumulado live.

## Mapeo de comentarios

El JSON opcional de mapeo usa patrones de texto simples, evaluados en orden:

```json
{
  "Strategy_1_": "XAU Breakout",
  "WF_Matrix_": "GBP Walk Forward",
  "USDJPY": "USDJPY Cluster"
}
```

Si ningún patrón coincide, usar el símbolo como bloque. Conservar también el comentario original para auditoría.

## Ambigüedades que requieren advertencia

- Balance inicial inferido en presencia de depósitos o retiros.
- Headline de beneficio que coincide con P/L bruto mientras `Comm/Swap` aparece separado.
- Símbolos con especificaciones diferentes entre backtest y live.
- Cuenta cent mezclada con USD sin conversión explícita.
- Cambio de riesgo, lotaje o conjunto de EAs durante el periodo.
- Captura de Myfxbook sin acceso a historial de operaciones.
