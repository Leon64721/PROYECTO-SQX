#!/usr/bin/env python3
"""Normalize QuantAnalyzer + MT5 data and generate monthly incubation analytics."""

from __future__ import annotations

import argparse
import json
import math
import re
import sys
from collections import OrderedDict
from pathlib import Path
from typing import Any

import matplotlib
matplotlib.use("Agg")
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from lxml import html


ASSET_PATTERNS = [
    r"XAUUSD", r"XAGUSD", r"XAUEUR", r"EURUSD", r"GBPUSD", r"USDJPY",
    r"USDCHF", r"USDCAD", r"AUDUSD", r"NZDUSD", r"AUDCAD", r"AUDJPY",
    r"EURJPY", r"GBPJPY", r"EURGBP", r"EURCAD", r"GBPCAD", r"CADJPY",
    r"USTEC", r"US100", r"NASDAQ", r"NDXUSD", r"US30", r"DOWUSD",
    r"SPXUSD", r"JP225", r"GER40", r"DAX", r"BTCUSD", r"ETHUSD",
]


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Analiza un portafolio mensual comparando QuantAnalyzer/CSV con MT5 HTML."
    )
    p.add_argument("--benchmark-csv", required=True, type=Path)
    p.add_argument("--mt5-html", required=True, type=Path)
    p.add_argument("--previous-mt5-html", type=Path)
    p.add_argument("--benchmark-json", type=Path)
    p.add_argument("--mapping-json", type=Path)
    p.add_argument("--portfolio", default="Portafolio")
    p.add_argument("--starting-balance", type=float)
    p.add_argument("--period-label")
    p.add_argument("--output-dir", required=True, type=Path)
    return p.parse_args()


def decode_html(path: Path) -> str:
    raw = path.read_bytes()
    for enc in ("utf-16", "utf-16le", "utf-8-sig", "utf-8"):
        try:
            text = raw.decode(enc)
            if "<html" in text.lower() or "<!doctype" in text.lower():
                return text
        except UnicodeDecodeError:
            continue
    raise ValueError(f"No se pudo decodificar el HTML: {path}")


def clean_number(value: Any) -> float | None:
    if value is None:
        return None
    s = str(value).replace("\xa0", " ").strip()
    if not s:
        return None
    match = re.search(r"[-+]?\d[\d\s,.]*", s)
    if not match:
        return None
    n = match.group(0).replace(" ", "")
    if "," in n and "." in n:
        if n.rfind(",") > n.rfind("."):
            n = n.replace(".", "").replace(",", ".")
        else:
            n = n.replace(",", "")
    elif "," in n:
        tail = n.split(",")[-1]
        n = n.replace(",", ".") if len(tail) <= 2 else n.replace(",", "")
    try:
        return float(n)
    except ValueError:
        return None


def parse_dt(value: str) -> pd.Timestamp:
    return pd.to_datetime(value, errors="raise")


def row_values(row) -> list[str]:
    return [" ".join(x.itertext()).strip() for x in row.xpath("./td|./th")]


def parse_mt5(path: Path) -> dict[str, Any]:
    doc = html.fromstring(decode_html(path))
    rows = doc.xpath("//tr")
    closed: list[dict[str, Any]] = []
    opened: list[dict[str, Any]] = []
    summary: dict[str, Any] = {}
    metadata: dict[str, str] = {}
    state = None

    known_labels = {
        "Total Net Profit": "total_net_profit",
        "Gross Profit": "gross_profit",
        "Gross Loss": "gross_loss",
        "Profit Factor": "profit_factor",
        "Expected Payoff": "expected_payoff",
        "Balance Drawdown Absolute": "balance_dd_absolute",
        "Balance Drawdown Maximal": "balance_dd_maximal",
        "Balance Drawdown Relative": "balance_dd_relative",
        "Profit Trades (% of total)": "profit_trades",
        "Loss Trades (% of total)": "loss_trades",
        "Largest profit trade": "largest_profit_trade",
        "Largest loss trade": "largest_loss_trade",
        "Maximum consecutive wins ($)": "max_consecutive_wins",
        "Maximum consecutive losses ($)": "max_consecutive_losses",
        "Balance": "balance",
    }

    for row in rows:
        vals = row_values(row)
        if not vals:
            continue
        compact = [v for v in vals if v != ""]
        if len(compact) == 1:
            marker = compact[0].strip()
            if marker == "Positions":
                state = "closed"
            elif marker == "Orders":
                state = "orders"
            elif marker == "Deals":
                state = "deals"
            elif marker == "Open Positions":
                state = "open"
            elif marker == "Working Orders":
                state = "working"
            elif marker == "Results":
                state = "results"

        for label in ("Account:", "Company:", "Date:"):
            if label in vals:
                idx = vals.index(label)
                if idx + 1 < len(vals):
                    metadata[label.rstrip(":").lower()] = vals[idx + 1]

        for raw_label, key in known_labels.items():
            label = raw_label + ":"
            if label in vals:
                idx = vals.index(label)
                if idx + 1 < len(vals):
                    summary[key] = vals[idx + 1]

        if state == "closed" and len(vals) in (13, 14):
            if len(vals[0]) != 19 or vals[3].lower() not in {"buy", "sell"}:
                continue
            try:
                if len(vals) == 14:
                    record = {
                        "OpenDT": parse_dt(vals[0]), "PositionID": vals[1],
                        "Symbol": vals[2], "Type": vals[3].lower(), "Comment": vals[4],
                        "Volume": float(vals[5]), "OpenPrice": float(vals[6]),
                        "SL": clean_number(vals[7]), "TP": clean_number(vals[8]),
                        "CloseDT": parse_dt(vals[9]), "ClosePrice": float(vals[10]),
                        "Commission": float(vals[11]), "Swap": float(vals[12]),
                        "Profit": float(vals[13]),
                    }
                else:
                    record = {
                        "OpenDT": parse_dt(vals[0]), "PositionID": vals[1],
                        "Symbol": vals[2], "Type": vals[3].lower(), "Comment": "",
                        "Volume": float(vals[4]), "OpenPrice": float(vals[5]),
                        "SL": clean_number(vals[6]), "TP": clean_number(vals[7]),
                        "CloseDT": parse_dt(vals[8]), "ClosePrice": float(vals[9]),
                        "Commission": float(vals[10]), "Swap": float(vals[11]),
                        "Profit": float(vals[12]),
                    }
                closed.append(record)
            except (ValueError, TypeError):
                continue

        if state == "open" and len(vals) == 12:
            if len(vals[0]) != 19 or vals[3].lower() not in {"buy", "sell"}:
                continue
            try:
                opened.append({
                    "OpenDT": parse_dt(vals[0]), "PositionID": vals[1],
                    "Symbol": vals[2], "Type": vals[3].lower(),
                    "Volume": float(vals[4]), "OpenPrice": float(vals[5]),
                    "SL": clean_number(vals[6]), "TP": clean_number(vals[7]),
                    "MarketPrice": float(vals[8]), "Swap": float(vals[9]),
                    "Profit": float(vals[10]), "Comment": vals[11],
                })
            except (ValueError, TypeError):
                continue

    closed_df = pd.DataFrame(closed)
    open_df = pd.DataFrame(opened)
    if closed_df.empty:
        raise ValueError("No se encontraron posiciones cerradas en el reporte MT5.")
    closed_df = closed_df.drop_duplicates(subset=["PositionID"], keep="last")
    report_net = clean_number(summary.get("total_net_profit"))
    raw_sum = float(closed_df["Profit"].sum())
    adjusted_sum = float((closed_df["Profit"] + closed_df["Commission"] + closed_df["Swap"]).sum())
    if report_net is not None and math.isclose(report_net, adjusted_sum, abs_tol=0.05):
        closed_df["NetPL"] = closed_df["Profit"] + closed_df["Commission"] + closed_df["Swap"]
        net_basis = "profit_plus_commission_swap"
    else:
        closed_df["NetPL"] = closed_df["Profit"]
        net_basis = "profit_column"
    return {
        "closed": closed_df.sort_values(["CloseDT", "PositionID"]).reset_index(drop=True),
        "open": open_df,
        "summary": summary,
        "metadata": metadata,
        "report_net": report_net,
        "raw_sum": raw_sum,
        "adjusted_sum": adjusted_sum,
        "net_basis": net_basis,
    }


def load_json(path: Path | None) -> dict[str, Any]:
    if path is None:
        return {}
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"El JSON debe contener un objeto: {path}")
    return data


def read_benchmark(path: Path, external: dict[str, Any]) -> tuple[pd.DataFrame, str, list[str]]:
    df = pd.read_csv(path)
    required = {"Symbol", "Open time", "Close time", "P/L in money"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Faltan columnas en el CSV: {sorted(missing)}")
    df["OpenDT"] = pd.to_datetime(df["Open time"], dayfirst=True, errors="raise")
    df["CloseDT"] = pd.to_datetime(df["Close time"], dayfirst=True, errors="raise")
    df["Profit"] = pd.to_numeric(df["P/L in money"], errors="raise")
    df["Costs"] = pd.to_numeric(df.get("Comm/Swap", 0), errors="coerce").fillna(0.0)
    raw = float(df["Profit"].sum())
    adjusted = float((df["Profit"] + df["Costs"]).sum())
    headline = external.get("headline_profit")
    warnings: list[str] = []
    if headline is not None and math.isclose(float(headline), adjusted, abs_tol=0.05):
        df["NetPL"] = df["Profit"] + df["Costs"]
        basis = "profit_plus_comm_swap"
    else:
        df["NetPL"] = df["Profit"]
        basis = "p_l_in_money"
        if abs(df["Costs"].sum()) > 0.01:
            warnings.append(
                "El CSV contiene Comm/Swap separado; la base principal usa P/L in money. "
                "Presentar también el escenario ajustado por costes."
            )
    if headline is not None and not (
        math.isclose(float(headline), raw, abs_tol=0.05)
        or math.isclose(float(headline), adjusted, abs_tol=0.05)
    ):
        warnings.append("El headline externo no reconcilia con el P/L bruto ni con el ajustado por costes.")
    df["Strategy"] = df["Symbol"].astype(str).str.replace(r"^Main:\s*", "", regex=True)
    return df.sort_values(["CloseDT", "OpenDT"]).reset_index(drop=True), basis, warnings


def stable_key(df: pd.DataFrame) -> pd.Series:
    if "PositionID" in df.columns and df["PositionID"].astype(str).str.len().gt(0).all():
        return df["PositionID"].astype(str)
    cols = ["OpenDT", "Symbol", "Type", "Volume", "Comment"]
    return df[cols].astype(str).agg("|".join, axis=1)


def longest_streak(values: pd.Series, positive: bool) -> tuple[int, float]:
    best_n = cur_n = 0
    best_sum = cur_sum = 0.0
    for value in values:
        hit = value > 0 if positive else value < 0
        if hit:
            cur_n += 1
            cur_sum += float(value)
            if cur_n > best_n:
                best_n, best_sum = cur_n, cur_sum
        else:
            cur_n, cur_sum = 0, 0.0
    return best_n, best_sum


def metrics(values: pd.Series, base_balance: float) -> dict[str, Any]:
    s = pd.to_numeric(values, errors="coerce").dropna()
    nonzero = s[s != 0]
    wins = nonzero[nonzero > 0]
    losses = nonzero[nonzero < 0]
    gp = float(wins.sum())
    gl = float(-losses.sum())
    equity = base_balance + s.cumsum()
    peaks = pd.concat([pd.Series([base_balance]), equity], ignore_index=True).cummax().iloc[1:].reset_index(drop=True)
    dd = equity.reset_index(drop=True) - peaks
    dd_pct = (-dd / peaks.replace(0, np.nan) * 100).max() if len(dd) else 0.0
    max_wins, max_wins_pl = longest_streak(nonzero, True)
    max_losses, max_losses_pl = longest_streak(nonzero, False)
    return {
        "trades": int(len(nonzero)),
        "zero_trades": int((s == 0).sum()),
        "profit": float(s.sum()),
        "return_pct": float(s.sum() / base_balance * 100) if base_balance else None,
        "profit_factor": gp / gl if gl else None,
        "win_rate_pct": float((nonzero > 0).mean() * 100) if len(nonzero) else None,
        "average_trade": float(nonzero.mean()) if len(nonzero) else None,
        "gross_profit": gp,
        "gross_loss": -gl,
        "largest_win": float(s.max()) if len(s) else None,
        "largest_loss": float(s.min()) if len(s) else None,
        "balance_dd_money_from_closes": float(-dd.min()) if len(dd) else 0.0,
        "balance_dd_pct_from_closes": float(dd_pct) if pd.notna(dd_pct) else None,
        "max_consecutive_wins": max_wins,
        "max_consecutive_wins_pl": max_wins_pl,
        "max_consecutive_losses": max_losses,
        "max_consecutive_losses_pl": max_losses_pl,
    }


def asset_from_text(text: str) -> str:
    upper = str(text).upper()
    for pattern in ASSET_PATTERNS:
        match = re.search(pattern, upper)
        if match:
            return match.group(0)
    token = re.split(r"[/_\s:-]+", upper)[0]
    return token or "OTRO"


def assign_blocks(df: pd.DataFrame, mapping: dict[str, str], text_cols: list[str]) -> pd.Series:
    def classify(row) -> str:
        text = " | ".join(str(row.get(c, "")) for c in text_cols)
        for pattern, label in mapping.items():
            if pattern.lower() in text.lower():
                return str(label)
        return asset_from_text(text)
    return df.apply(classify, axis=1)


def group_stats(df: pd.DataFrame, pl_col: str) -> list[dict[str, Any]]:
    out = []
    for block, part in df.groupby("Block", sort=False):
        st = metrics(part[pl_col], 10000.0)
        out.append({"block": str(block), **{k: st[k] for k in (
            "trades", "profit", "profit_factor", "win_rate_pct", "average_trade"
        )}})
    return sorted(out, key=lambda x: x["profit"], reverse=True)


def make_serializable(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): make_serializable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [make_serializable(v) for v in value]
    if isinstance(value, (pd.Timestamp, pd.Period)):
        return str(value)
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return None if not np.isfinite(value) else float(value)
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def mpl_setup() -> None:
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 9,
        "axes.edgecolor": "#D9E0E6", "axes.labelcolor": "#607080",
        "xtick.color": "#607080", "ytick.color": "#607080",
        "text.color": "#16202A", "figure.facecolor": "white",
        "axes.facecolor": "white",
    })


def save_fig(fig, path: Path) -> None:
    fig.savefig(path, dpi=220, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def generate_charts(
    outdir: Path, benchmark: pd.DataFrame, live: pd.DataFrame,
    benchmark_metrics: dict[str, Any], live_metrics: dict[str, Any],
    base_balance: float, benchmark_months: int, live_months: float,
) -> dict[str, str]:
    mpl_setup()
    charts: dict[str, str] = {}

    names = ["Profit factor", "Win rate", "Promedio/trade", "P/L mensual", "Trades/mes"]
    hist_month_pl = benchmark_metrics["profit"] / benchmark_months
    hist_month_n = benchmark_metrics["trades"] / benchmark_months
    live_month_pl = live_metrics["profit"] / live_months
    live_month_n = live_metrics["trades"] / live_months
    pairs = [
        (live_metrics["profit_factor"], benchmark_metrics["profit_factor"]),
        (live_metrics["win_rate_pct"], benchmark_metrics["win_rate_pct"]),
        (live_metrics["average_trade"], benchmark_metrics["average_trade"]),
        (live_month_pl, hist_month_pl), (live_month_n, hist_month_n),
    ]
    vals = [a / b * 100 if a is not None and b not in (None, 0) else np.nan for a, b in pairs]
    fig, ax = plt.subplots(figsize=(7.6, 3.2))
    y = np.arange(len(names))[::-1]
    bars = ax.barh(y, vals[::-1], color=["#0B8A68" if v >= 100 else "#2F6F9F" for v in vals[::-1]])
    ax.set_yticks(y, names[::-1]); ax.axvline(100, color="#D8A62A", ls="--", lw=2)
    finite = [v for v in vals if np.isfinite(v)]
    ax.set_xlim(0, max(150, max(finite, default=100) + 18)); ax.grid(axis="x", alpha=.2)
    ax.spines[["top", "right", "left"]].set_visible(False)
    for bar, val in zip(bars, vals[::-1]):
        if np.isfinite(val):
            ax.text(val + 2, bar.get_y()+bar.get_height()/2, f"{val:.0f}", va="center", fontweight="bold")
    ax.set_xlabel("Índice relativo (benchmark = 100)")
    fig.tight_layout()
    path = outdir / "01_parity_index.png"; save_fig(fig, path); charts["parity"] = str(path)

    hist_blocks = benchmark.groupby("Block")["NetPL"].sum() / benchmark_months
    live_blocks = live.groupby("Block")["NetPL"].sum() / live_months
    blocks = list(OrderedDict.fromkeys(list(live_blocks.sort_values(ascending=False).index) + list(hist_blocks.index)))
    plot = pd.DataFrame({"Histórico/mes": hist_blocks, "Live/mes": live_blocks}).reindex(blocks).fillna(0)
    fig_w = max(7.6, min(13, 1.2 * len(plot)))
    fig, ax = plt.subplots(figsize=(fig_w, 3.5))
    x = np.arange(len(plot)); width = .36
    b1 = ax.bar(x-width/2, plot["Histórico/mes"], width, color="#8AAEC8", label="Histórico/mes")
    b2 = ax.bar(x+width/2, plot["Live/mes"], width, color=["#0B8A68" if v >= 0 else "#C84848" for v in plot["Live/mes"]], label="Live/mes")
    ax.set_xticks(x, plot.index, rotation=30 if len(plot) > 5 else 0, ha="right" if len(plot)>5 else "center")
    ax.axhline(0, color="#16202A", lw=.8); ax.grid(axis="y", alpha=.2); ax.set_ylabel("P/L")
    ax.spines[["top", "right"]].set_visible(False); ax.legend(frameon=False)
    for bars in (b1, b2):
        for bar in bars:
            value = bar.get_height(); ax.text(bar.get_x()+bar.get_width()/2, value, f"{value:,.0f}", ha="center", va="bottom" if value>=0 else "top", fontsize=7)
    fig.tight_layout()
    path = outdir / "02_attribution.png"; save_fig(fig, path); charts["attribution"] = str(path)

    eq = base_balance + live["NetPL"].cumsum()
    peaks = pd.concat([pd.Series([base_balance]), eq], ignore_index=True).cummax().iloc[1:].reset_index(drop=True)
    dd = eq.reset_index(drop=True) - peaks
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(7.6, 4.5), sharex=True, gridspec_kw={"height_ratios": [2.1, 1], "hspace": .08})
    ax1.plot(live["CloseDT"], eq, color="#0B8A68", lw=2.3); ax1.fill_between(live["CloseDT"], base_balance, eq, color="#DDF4EB")
    ax1.axhline(base_balance, color="#607080", ls="--", lw=.8); ax1.set_ylabel("Balance"); ax1.grid(alpha=.18)
    ax1.spines[["top", "right"]].set_visible(False)
    ax2.plot(live["CloseDT"], dd, color="#C84848", lw=1.4); ax2.fill_between(live["CloseDT"], dd, 0, color="#F3B4B4")
    ax2.set_ylabel("DD"); ax2.grid(alpha=.18); ax2.spines[["top", "right"]].set_visible(False)
    ax2.xaxis.set_major_formatter(mdates.DateFormatter("%d-%b")); fig.tight_layout()
    path = outdir / "03_live_balance_drawdown.png"; save_fig(fig, path); charts["live_curve"] = str(path)

    annual = benchmark.groupby(benchmark["CloseDT"].dt.year)["NetPL"].sum()
    fig, ax = plt.subplots(figsize=(7.6, 3.4))
    colors = ["#C84848" if v < 0 else "#2F6F9F" for v in annual]
    bars = ax.bar(annual.index.astype(str), annual.values, color=colors)
    ax.axhline(0, color="#16202A", lw=.8); ax.grid(axis="y", alpha=.2); ax.set_ylabel("P/L anual")
    ax.spines[["top", "right"]].set_visible(False)
    for bar, value in zip(bars, annual):
        ax.text(bar.get_x()+bar.get_width()/2, value, f"{value:,.0f}", ha="center", va="bottom" if value>=0 else "top", fontsize=7, fontweight="bold")
    fig.tight_layout()
    path = outdir / "04_historical_annual.png"; save_fig(fig, path); charts["annual"] = str(path)

    monthly = benchmark.set_index("CloseDT")["NetPL"].resample("ME").sum().tail(6)
    labels = [p.strftime("%b-%y") for p in monthly.index] + ["Live"]
    values = list(monthly.values) + [live_month_pl]
    fig, ax = plt.subplots(figsize=(7.6, 3.2))
    bars = ax.bar(labels, values, color=["#2F6F9F"]*len(monthly) + ["#0B8A68" if live_month_pl>=0 else "#C84848"])
    ax.axhline(hist_month_pl, color="#D8A62A", ls="--", lw=2, label=f"Promedio histórico: {hist_month_pl:,.0f}")
    ax.grid(axis="y", alpha=.2); ax.set_ylabel("P/L mensual"); ax.spines[["top", "right"]].set_visible(False); ax.legend(frameon=False)
    for bar, value in zip(bars, values):
        ax.text(bar.get_x()+bar.get_width()/2, value, f"{value:,.0f}", ha="center", va="bottom" if value>=0 else "top", fontsize=7)
    fig.tight_layout()
    path = outdir / "05_recent_months.png"; save_fig(fig, path); charts["recent_months"] = str(path)
    return charts


def main() -> int:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    external = load_json(args.benchmark_json)
    mapping = load_json(args.mapping_json)
    benchmark, benchmark_basis, warnings = read_benchmark(args.benchmark_csv, external)
    mt5 = parse_mt5(args.mt5_html)
    live_all = mt5["closed"].copy()
    period = live_all.copy()

    if args.previous_mt5_html:
        previous = parse_mt5(args.previous_mt5_html)["closed"].copy()
        prev_keys = set(stable_key(previous))
        keys = stable_key(live_all)
        period = live_all.loc[~keys.isin(prev_keys)].copy()
        if period.empty:
            raise ValueError("El export actual no contiene posiciones nuevas frente al corte anterior.")
    else:
        previous = pd.DataFrame()

    benchmark["Block"] = assign_blocks(benchmark, mapping, ["Strategy", "Symbol"])
    live_all["Block"] = assign_blocks(live_all, mapping, ["Comment", "Symbol"])
    period["Block"] = assign_blocks(period, mapping, ["Comment", "Symbol"])

    if args.starting_balance is not None:
        starting_balance = float(args.starting_balance)
        starting_balance_source = "user"
    else:
        final_balance = clean_number(mt5["summary"].get("balance"))
        total_net = mt5["report_net"]
        if final_balance is None or total_net is None:
            raise ValueError("No se pudo inferir el balance inicial; usar --starting-balance.")
        starting_balance = final_balance - total_net
        starting_balance_source = "inferred_final_balance_minus_net_profit"
        warnings.append("El balance inicial fue inferido; confirmar que no existan depósitos o retiros.")

    if not previous.empty:
        period_base = starting_balance + float(previous["NetPL"].sum())
    else:
        period_base = starting_balance

    benchmark_metrics = metrics(benchmark["NetPL"], starting_balance)
    live_metrics = metrics(period["NetPL"], period_base)
    cumulative_metrics = metrics(live_all["NetPL"], starting_balance)
    benchmark_months = int(benchmark["CloseDT"].dt.to_period("M").nunique())
    live_days = max((period["CloseDT"].max() - period["OpenDT"].min()).total_seconds() / 86400, 1)
    live_months = max(live_days / 30.4375, 1 / 30.4375)

    hist_month_profit = benchmark_metrics["profit"] / benchmark_months
    hist_month_trades = benchmark_metrics["trades"] / benchmark_months
    live_month_profit = live_metrics["profit"] / live_months
    live_month_trades = live_metrics["trades"] / live_months
    parity = {
        "profit_factor": live_metrics["profit_factor"] / benchmark_metrics["profit_factor"] * 100 if benchmark_metrics["profit_factor"] else None,
        "win_rate": live_metrics["win_rate_pct"] / benchmark_metrics["win_rate_pct"] * 100 if benchmark_metrics["win_rate_pct"] else None,
        "average_trade": live_metrics["average_trade"] / benchmark_metrics["average_trade"] * 100 if benchmark_metrics["average_trade"] else None,
        "monthly_profit": live_month_profit / hist_month_profit * 100 if hist_month_profit else None,
        "monthly_trades": live_month_trades / hist_month_trades * 100 if hist_month_trades else None,
    }

    if "Sample type" in benchmark.columns:
        sample_counts = benchmark["Sample type"].fillna("MISSING").value_counts().to_dict()
        if set(sample_counts) == {"IS"}:
            warnings.append("Todas las operaciones del benchmark están clasificadas como IS; no existe OOS explícito.")
    else:
        sample_counts = {}
        warnings.append("El benchmark no contiene una columna Sample type.")

    if live_metrics["trades"] < 100:
        warnings.append("La muestra live es menor a 100 trades; el dictamen debe describirse como preliminar.")
    if mt5["report_net"] is not None and not math.isclose(mt5["report_net"], float(live_all["NetPL"].sum()), abs_tol=0.05):
        warnings.append("El Total Net Profit del MT5 no reconcilia con la suma de posiciones cerradas.")

    open_df = mt5["open"]
    open_float = float((open_df.get("Profit", pd.Series(dtype=float)) + open_df.get("Swap", pd.Series(dtype=float))).sum()) if not open_df.empty else 0.0
    final_balance_est = starting_balance + cumulative_metrics["profit"]
    equity_est = final_balance_est + open_float

    period.to_csv(args.output_dir / "live_period_trades.csv", index=False)
    live_all.to_csv(args.output_dir / "live_cumulative_trades.csv", index=False)
    benchmark.to_csv(args.output_dir / "benchmark_normalized.csv", index=False)

    charts = generate_charts(
        args.output_dir, benchmark, period, benchmark_metrics, live_metrics,
        period_base, benchmark_months, live_months,
    )

    annual = benchmark.groupby(benchmark["CloseDT"].dt.year)["NetPL"].sum().round(8).to_dict()
    monthly = benchmark.groupby(benchmark["CloseDT"].dt.to_period("M"))["NetPL"].sum().round(8).to_dict()
    result = {
        "meta": {
            "portfolio": args.portfolio,
            "period_label": args.period_label,
            "benchmark_start": benchmark["OpenDT"].min(),
            "benchmark_end": benchmark["CloseDT"].max(),
            "live_period_start": period["OpenDT"].min(),
            "live_period_end": period["CloseDT"].max(),
            "starting_balance": starting_balance,
            "starting_balance_source": starting_balance_source,
            "period_starting_balance": period_base,
            "account": mt5["metadata"].get("account"),
            "company": mt5["metadata"].get("company"),
        },
        "data_quality": {
            "warnings": list(OrderedDict.fromkeys(warnings)),
            "benchmark_basis": benchmark_basis,
            "mt5_net_basis": mt5["net_basis"],
            "benchmark_sample_counts": sample_counts,
            "benchmark_zero_trades": int((benchmark["NetPL"] == 0).sum()),
            "benchmark_costs_total": float(benchmark["Costs"].sum()),
            "benchmark_profit_raw": float(benchmark["Profit"].sum()),
            "benchmark_profit_adjusted": float((benchmark["Profit"] + benchmark["Costs"]).sum()),
            "mt5_report_total_net_profit": mt5["report_net"],
        },
        "benchmark": {
            **benchmark_metrics,
            "months": benchmark_months,
            "monthly_profit": hist_month_profit,
            "monthly_trades": hist_month_trades,
            "external_stats": external,
        },
        "live_period": {
            **live_metrics,
            "elapsed_days": live_days,
            "month_equivalent": live_months,
            "monthly_profit_equivalent": live_month_profit,
            "monthly_trades_equivalent": live_month_trades,
        },
        "live_cumulative": cumulative_metrics,
        "open_positions": {
            "count": int(len(open_df)), "floating_profit_and_swap": open_float,
            "estimated_final_balance": final_balance_est, "estimated_equity": equity_est,
        },
        "parity_index": parity,
        "attribution": {
            "benchmark": group_stats(benchmark, "NetPL"),
            "live_period": group_stats(period, "NetPL"),
        },
        "historical_annual": annual,
        "historical_monthly": monthly,
        "mt5_report_summary": mt5["summary"],
        "charts": charts,
    }
    output_json = args.output_dir / "analysis.json"
    output_json.write_text(json.dumps(make_serializable(result), ensure_ascii=False, indent=2), encoding="utf-8")
    print(output_json)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise
