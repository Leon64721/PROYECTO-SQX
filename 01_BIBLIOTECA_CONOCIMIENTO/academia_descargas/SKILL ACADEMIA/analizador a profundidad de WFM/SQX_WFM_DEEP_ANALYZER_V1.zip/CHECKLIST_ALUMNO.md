# CHECKLIST DEL ALUMNO — WFM

Antes de aceptar una interpretación WFM:

[ ] ¿Subí el `.sqx`, no solo una captura?
[ ] ¿Se distinguió Main/original de WF?
[ ] ¿Se reconstruyó toda la matriz?
[ ] ¿Se identificaron todos los filtros?
[ ] ¿Se identificó thresholdPct?
[ ] ¿Se identificó robCombRows × robCombCols y robMinComb?
[ ] ¿Se excluyó el future period?
[ ] ¿Se reprodujo WF Stability de Ret/DD?
[ ] ¿Se revisaron runs IS/OOS?
[ ] ¿Se revisó # trades OOS?
[ ] ¿Se revisó Parameter Stability?
[ ] ¿Se auditaron parámetros y límites?
[ ] ¿Se analizaron vecinos de las celdas verdes?
[ ] ¿Se buscó una meseta, no un punto?
[ ] ¿No se bajó el threshold para rescatar?
[ ] ¿El resultado final es APROBADA o DESCARTADA?
