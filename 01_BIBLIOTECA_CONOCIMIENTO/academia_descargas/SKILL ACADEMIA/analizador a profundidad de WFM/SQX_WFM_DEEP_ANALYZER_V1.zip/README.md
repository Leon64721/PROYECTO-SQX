# SQX WFM DEEP ANALYZER V1

Skill educativa y operativa para interpretar Walk-Forward Matrix de StrategyQuant X directamente desde una estrategia `.sqx`.

## Uso recomendado

1. Subir el archivo `.sqx`.
2. Pegar el prompt de `PROMPT_ACTIVACION.txt`.
3. Adjuntar captura solo si se quiere hacer cross-check visual.
4. El análisis debe usar el `.sqx` como fuente primaria.

## Objetivo

Evitar errores comunes:
- confundir la estrategia original con una run WFM;
- confundir WF Final Result con WF Stability;
- valorar una estrategia solo por una celda verde;
- ignorar la meseta 3×3 u otra regla configurada;
- ignorar `futurePeriod`;
- rescatar estrategias bajando thresholds después de ver la matriz.

## Salida

- matriz completa;
- condiciones exactas;
- WF Stability;
- Parameter Stability;
- runs IS/OOS;
- meseta/vecindad;
- parámetros;
- muestra;
- diagnóstico;
- APROBADA WFM / DESCARTADA WFM.
