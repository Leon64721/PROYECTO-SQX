# SQX WFM DEEP ANALYZER V1.0
## Auditoría profunda de Walk-Forward Matrix desde una estrategia `.sqx`

### Propósito

Esta skill analiza una estrategia de StrategyQuant X en formato `.sqx` que contenga resultados de Walk-Forward / Walk-Forward Matrix (WFM), para explicar con precisión qué está mostrando SQX y si la estrategia demuestra estabilidad temporal.

La skill está diseñada para resolver dudas como:

- ¿Por qué SQX muestra `FAILED` si el Ret/DD final es alto?
- ¿Cuál es exactamente el `WF Stability of Ret/DD Ratio`?
- ¿Qué diferencia hay entre la estrategia original, el WF Final Result y WF Stability?
- ¿Cuántas celdas de la matriz pasan realmente?
- ¿Existe una meseta robusta o solo puntos verdes aislados?
- ¿Los parámetros son estables aunque el rendimiento OOS no lo sea?
- ¿Hay dependencia de régimen?
- ¿Qué runs destruyen la estabilidad?
- ¿Está bien configurado el filtro de WFM?
- ¿Debe aprobarse o descartarse la estrategia dentro del pipeline?

Regla central:

> NO interpretar una WFM mirando únicamente el resultado agregado ni una captura aislada.

El flujo obligatorio es:

```text
.sqx
→ estructura interna
→ configuración WFM
→ matriz completa
→ condiciones del filtro
→ runs IS/OOS por celda
→ WF Final Result
→ WF Stability
→ Parameter Stability
→ superficie/meseta
→ diagnóstico
→ PASS / FAIL
```

---

# 1. Input obligatorio

El usuario debe subir:

```text
1. Estrategia StrategyQuant X en formato .sqx
```

Inputs opcionales:

```text
2. Captura de WFM si quiere validar lo mostrado visualmente.
3. Objetivo:
   - incubación
   - portafolio
   - fondeo
   - research
4. Umbrales de robustez deseados si son distintos de los guardados en el .sqx.
5. Resultado previo de Tick/SPP/MC si quiere una decisión integral.
```

La skill debe intentar resolver el análisis directamente desde el `.sqx`.

No pedir capturas si el archivo contiene la información necesaria.

Si una métrica concreta no puede recuperarse de forma fiable del archivo:
- declararlo;
- pedir solo el export/captura mínima necesaria;
- no inventar el valor.

---

# 2. Principio de fuente primaria

El `.sqx` es la fuente primaria.

Una estrategia `.sqx` de SQX puede contener internamente, entre otros:

```text
settings.xml
lastSettings.xml
strategy_Portfolio.xml
version.txt
Results/.../dailyEquity.bin
orders.bin
```

Para WFM, inspeccionar primero:

```text
settings.xml
```

Buscar:

```xml
<WalkForwardResult>
  <MatrixResult ...>
    <RunResult ...>
      <Periods>
        <WalkForwardPeriod ...>
```

También buscar:

```text
<WalkForwardConditions>
<SpecialValuesMap>
ParametersStability_WF_...
```

No confundir resultados de:

```text
Main: símbolo/timeframe
```

con resultados:

```text
WF: N runs : X % OOS
```

---

# 3. Auditoría inicial del archivo

Reportar:

```text
ARCHIVO
- Nombre:
- ¿Es ZIP/JAR válido?:
- Versión SQX si aparece:
- Strategy name:
- Símbolo:
- Timeframe:
- Fecha inicial:
- Fecha final:
- ¿Contiene WalkForwardResult?:
- ¿Contiene MatrixResult?:
- Número de combinaciones:
- Estado de lectura: COMPLETO / PARCIAL / NO DECODIFICABLE
```

Si no existe WFM dentro del archivo:

```text
NO HAY WFM ALMACENADA EN ESTE .sqx
```

y detener el análisis WFM.

---

# 4. Reconstrucción de la matriz

Leer de `MatrixResult`:

```text
start1
stop1
increment1
start2
stop2
increment2
periodType
```

Normalmente:
- un eje representa OOS%;
- otro eje representa número de runs.

Confirmarlo usando:

```text
RunResult/@param1
RunResult/@param2
RunResult/@resultName
```

Ejemplo:

```text
resultName="WF: 5 runs : 36 % OOS"
```

No asumir el significado de param1/param2 sin verificar `resultName`.

Calcular:

```text
N_FILAS
N_COLUMNAS
TOTAL_CELDAS = N_FILAS × N_COLUMNAS
```

Generar una tabla completa:

```text
Runs \ OOS%
```

con una fila por runs y una columna por OOS.

---

# 5. Diferenciar CUATRO conceptos

Esta separación es obligatoria en todo reporte.

## 5.1 Estrategia original

Es el resultado de:

```text
Main: símbolo/timeframe
```

con sus parámetros fijos originales.

Pregunta que responde:

> ¿Cómo funcionó la estrategia original con sus parámetros actuales?

NO usar sus métricas para calcular automáticamente WF Stability.

---

## 5.2 WF Final Result

Es el resultado Walk-Forward agregado/concatenado de una combinación concreta.

Ejemplo:

```text
WF Ret/DD Ratio = 10.96
```

Pregunta que responde:

> ¿Cómo quedó el resultado Walk-Forward final de esta configuración?

Puede ser excelente incluso cuando la estabilidad IS→OOS es pobre.

---

## 5.3 WF Stability

Pregunta:

> ¿Cuánto del desempeño observado en las ventanas de optimización/IS se conserva en las correspondientes ventanas Run/OOS?

Para `Ret/DD Ratio`, cuando los valores por run están disponibles y la fórmula se reproduce contra SQX:

```text
WF Stability Ret/DD
=
Promedio(Ret/DD OOS de runs reales)
/
Promedio(Ret/DD IS de runs reales)
× 100
```

Excluir la fila marcada:

```text
futurePeriod="true"
```

Ejemplo:

```text
Ret/DD IS:
7.33, 8.06, 11.11, 7.34

Ret/DD OOS:
1.94, 0.71, 1.24, 6.42

mean OOS / mean IS × 100
≈ 30.47%
```

La skill debe comprobar que el cálculo reproduce el valor que SQX almacena/muestra.

### Regla crítica

NO generalizar esta fórmula sin validación a todas las métricas WFM.

Algunas métricas dependientes del tiempo pueden requerir normalización propia de SQX.

Para cada métrica:
- usar primero el valor SQX almacenado;
- reproducirlo matemáticamente si es posible;
- si la fórmula no está confirmada, declararlo.

---

## 5.4 Parameter Stability

Es distinta de WF Stability.

Pregunta:

> ¿Qué tan estable es la selección de parámetros entre las distintas optimizaciones?

Leer valores como:

```text
ParametersStability_WF_5_runs_36_OOS
```

Reportar:

```text
media
mediana
mínimo
máximo
```

y por celda.

Interpretación importante:

```text
Parameter Stability alta
+
WF Performance Stability baja
```

sugiere que los parámetros pueden ser relativamente coherentes pero el edge cambia de fuerza entre regímenes.

Eso es una posible dependencia de régimen, no una prueba definitiva.

---

# 6. Extracción de condiciones WFM

Leer:

```xml
<WalkForwardConditions>
  <Conditions
     thresholdPct="..."
     robCombRows="..."
     robCombCols="..."
     robMinComb="...">
```

Para cada `<Condition use="true">` extraer:

```text
Left side
Metric/class
resultType
subresult
Comparator
Right-side type
Threshold
pctRatio
```

En archivos donde se confirme:

```text
subresult=30 → WF Final Result
subresult=31 → WF Stability
```

No asumir este mapa en archivos incompatibles; verificar contra los valores/capturas/nombres si existe duda.

Reportar literalmente la condición.

Ejemplo:

```text
1. WF Ret/DD Ratio >= 1.25
2. WF Stability of Ret/DD Ratio > 50%
```

---

# 7. Robustness Score por celda

SQX puede calcular:

```text
Robustness Score
=
# condiciones activas aprobadas
/
# condiciones activas totales
× 100
```

Ejemplo con 2 condiciones:

```text
2/2 = 100%
1/2 = 50%
0/2 = 0%
```

Si:

```text
thresholdPct = 70
```

entonces con solo 2 condiciones:

```text
100% = PASS
50%  = FAIL
```

Explicar esta discretización al alumno.

No interpretar `70%` como si cada métrica individual necesitara 70%.

---

# 8. Criterio de MESSETA / grupo robusto

Extraer:

```text
robCombRows
robCombCols
robMinComb
thresholdPct
```

Ejemplo:

```text
3 × 3
al menos 7 resultados
con Robustness Score >= 70%
```

Esto significa:

> Debe existir al menos una región local 3×3 donde 7 de las 9 celdas pasen el threshold.

La skill debe:

```text
1. reconstruir matriz PASS/FAIL;
2. contar total de celdas que pasan;
3. calcular % de celdas que pasan;
4. buscar todas las ventanas robCombRows × robCombCols;
5. determinar el mejor grupo;
6. comparar mejor grupo vs robMinComb;
7. identificar si las celdas verdes son contiguas o aisladas.
```

### Interpretación

Meseta robusta:

```text
varias celdas vecinas pasan
cambios graduales
no depende de una combinación exacta
```

Punto aislado:

```text
una o pocas celdas pasan
vecinos inmediatos fallan
alta fragilidad respecto a longitud de IS/OOS o número de runs
```

---

# 9. Matriz numérica obligatoria

Entregar, como mínimo, una matriz para cada métrica central disponible:

```text
WF Final Result
WF Stability
Parameter Stability
PASS/FAIL
```

Ejemplo:

```text
WF Stability Ret/DD

             OOS%
Runs     20    22    24 ...
4       30.5  31.0  32.2
5       ...
```

Además resumir:

```text
media
mediana
p10
p25
p75
p90
mínimo
máximo
# >= threshold
% >= threshold
```

No limitarse al mejor valor.

---

# 10. Análisis profundo de runs IS/OOS

Para cada celda relevante analizar sus runs reales.

Excluir:

```text
futurePeriod=true
```

Por run reportar cuando esté disponible:

```text
Periodo IS
Periodo OOS
Days IS
Days OOS
# trades IS
# trades OOS
Ret/DD IS
Ret/DD OOS
Net Profit IS
Net Profit OOS
DD IS
DD OOS
Avg Trade
Parameters
```

Calcular:

```text
Retención por run = OOS / IS
```

cuando sea matemáticamente coherente.

No promediar ratios individuales y llamarlo WF Stability si SQX usa ratio de promedios.

Mostrar ejemplos de degradación:

```text
IS 10.14 → OOS 0.25
```

y de mejora:

```text
IS 1.81 → OOS 5.14
```

---

# 11. Diagnóstico de degradación IS → OOS

Clasificar el patrón.

## A. CONSISTENTE

La mayoría de runs conserva un porcentaje similar.

## B. ASIMÉTRICO

Algunos runs mejoran mucho y otros colapsan.

## C. DETERIORO GENERALIZADO

La mayoría de runs OOS es claramente peor.

## D. REGIME-DEPENDENT

Los resultados cambian mucho entre periodos aun con parámetros similares.

## E. MUESTRA INSUFICIENTE

Muy pocos trades OOS para interpretar con confianza.

La etiqueta es diagnóstico, no prueba causal.

---

# 12. Auditoría de parámetros

Leer `testParameters` de:

```text
RunResult
WalkForwardPeriod
```

Para cada parámetro calcular:

```text
- valores usados;
- frecuencia;
- moda;
- media/mediana si numérico;
- mínimo/máximo;
- % de veces en límite inferior;
- % de veces en límite superior;
- cantidad de valores distintos.
```

Alertas:

```text
BOUNDARY_LOW
BOUNDARY_HIGH
PARAMETER_COLLAPSE
PARAMETER_JUMPING
```

Heurística orientativa:

```text
>70% de selecciones en un límite → revisar rango.
>90% → alerta fuerte.
```

No modificar automáticamente el rango.

Recomendar SPP/ampliación controlada si el óptimo golpea repetidamente el límite.

---

# 13. Concentración temporal

Cuando NetProfit por run sea legible:

```text
Profit contribution run
=
NetProfit OOS del run
/
suma NetProfit OOS positivos o total según contexto
```

Reportar:

```text
mejor run como % del total
top 2 runs como % del total
# runs positivos
# runs negativos
% profitable runs
```

Comparar con el filtro configurado si existe.

Advertir:

```text
4 runs naturalmente generan más concentración por run que 8–10 runs.
```

No penalizar sin considerar el número de ventanas.

---

# 14. Sample-size Gate

No interpretar WF Stability sin número de trades.

Por celda calcular:

```text
media trades OOS/run
mínimo trades OOS/run
total trades OOS
```

Advertir:

```text
STABILITY_SAMPLE_WEAK
```

si uno o varios runs tienen una muestra demasiado pequeña para el edge/timeframe.

No usar un mínimo universal.

Considerar:
- timeframe;
- edge;
- duración de OOS;
- frecuencia esperada.

---

# 15. Sensitivity Map del threshold

Permitido SOLO como diagnóstico.

Ejemplo:

```text
celdas >= 40%
celdas >= 45%
celdas >= 50%
celdas >= 60%
```

Objetivo:

> entender si existe una meseta moderada justo debajo del gate.

Prohibido:

```text
ver que 40% pasa
→ bajar el gate de 50% a 40%
→ rescatar la estrategia
```

Eso sería optimizar el test después de mirar el resultado.

La skill debe mantener separado:

```text
CONFIGURED GATE
vs
DIAGNOSTIC SENSITIVITY
```

---

# 16. Comparación original vs WFM

Crear una sección específica:

```text
ESTRATEGIA ORIGINAL
WF FINAL RESULT
WF STABILITY
PARAMETER STABILITY
```

No mezclar valores.

Preguntas:

```text
1. ¿La estrategia fija original es buena?
2. ¿La reoptimización produce un WF final bueno?
3. ¿La ventaja IS se conserva OOS?
4. ¿Los parámetros seleccionados son estables?
5. ¿Existe una región amplia de WFM?
```

Una estrategia puede responder:

```text
1 = Sí
2 = Sí
3 = No
4 = Sí
5 = No
```

y por tanto fallar WFM aunque la curva original sea buena.

---

# 17. Tipos de fallo WFM

Asignar uno o varios:

```text
FAIL_ABSOLUTE_PERFORMANCE
FAIL_WF_STABILITY
FAIL_NO_PLATEAU
FAIL_TOO_FEW_PASSING_CELLS
FAIL_SAMPLE_SIZE
FAIL_PARAMETER_BOUNDARY
FAIL_PARAMETER_INSTABILITY
FAIL_PROFIT_CONCENTRATION
FAIL_REGIME_DEPENDENCE_SUSPECTED
FAIL_FILTER_CONFIGURATION
```

No usar `FAIL_REGIME_DEPENDENCE_SUSPECTED` como certeza causal.

---

# 18. Validación del filtro

La skill debe revisar si las condiciones están conceptualmente bien construidas.

Ejemplo correcto:

```text
WF Stability of Ret/DD Ratio >= 50
```

Ejemplo sospechoso:

```text
WF Stability of Ret/DD Ratio >= 50% of Main Data Ret/DD Ratio
```

porque se comparan magnitudes conceptualmente distintas.

Revisar:

```text
- métrica izquierda;
- result type;
- subresult;
- numeric vs column right side;
- pctRatio;
- comparador;
- threshold.
```

Si el filtro está mal configurado:
- explicar;
- no evaluar la estrategia como si el filtro fuera correcto;
- ofrecer cálculo bajo filtro corregido por separado.

---

# 19. Umbrales interpretativos de WF Stability Ret/DD

Estos son niveles descriptivos, NO reglas universales:

```text
<30%      muy débil
30–50%    degradación importante
50–60%    mínimo aceptable si el gate es 50%
60–75%    bueno
75–100%   fuerte
~100%     OOS conserva aproximadamente IS
>100%     OOS supera IS; revisar muestra/concentración
```

La decisión oficial debe usar el gate almacenado/configurado, no esta tabla.

---

# 20. Regla de decisión

Primero reportar:

```text
SQX WFM RESULT:
PASS / FAIL
```

según las condiciones guardadas.

Luego un subtipo diagnóstico:

```text
PASS_STRONG_PLATEAU
PASS_THIN_PLATEAU
PASS_ISOLATED_CELLS
FAIL_NEAR_GATE
FAIL_STRUCTURAL
FAIL_FILTER_ERROR
```

### FAIL_STRUCTURAL

Usar cuando, por ejemplo:

```text
muy pocas celdas pasan
mejor grupo muy lejos del requerido
stability media muy inferior al gate
no hay meseta
```

### FAIL_NEAR_GATE

Solo si el proyecto falla por poco:

```text
ej. requerido 7/9 y obtiene 6/9
```

No llamar "near" a:

```text
2/9 vs 7/9
```

---

# 21. Relación con el pipeline de robustez

WFM no debe evaluarse en aislamiento si el usuario pide decisión final.

Contexto recomendado:

```text
OOS
→ MC Trades
→ MC Spread/Slippage
→ Tick
→ SPP
→ WFM
→ MT5
```

Si el usuario solo sube `.sqx` de WFM:
- evaluar WFM profundamente;
- no inventar resultados de etapas anteriores.

Si aporta Tick/SPP/MC:
- integrar la decisión.

---

# 22. Formato obligatorio del reporte

## A. Resumen ejecutivo

```text
Strategy:
Symbol:
TF:
WFM:
Cells:
Passed cells:
Configured gate:
Best group:
Verdict:
```

## B. Qué está midiendo SQX

Explicar:
- Original;
- WF Final;
- WF Stability;
- Parameter Stability.

## C. Configuración WFM extraída

```text
Runs:
OOS range:
Increment:
Total cells:
Filter:
Plateau rule:
```

## D. Matrix WF Final Result

Tabla.

## E. Matrix WF Stability

Tabla.

## F. Matrix Parameter Stability

Tabla.

## G. PASS/FAIL map

Tabla.

## H. Estadística global

```text
mean/median/min/max
pass %
distance to gate
```

## I. Runs de celdas relevantes

Analizar:
- mejores;
- peores;
- verdes;
- celdas vecinas;
- celda recomendada por SQX.

## J. Parameter audit

## K. Sample-size audit

## L. Plateau / surface audit

## M. Failure diagnosis

## N. Veredicto

```text
APROBADA WFM
DESCARTADA WFM
```

## O. Siguiente acción

Ejemplos:
- continuar a MT5;
- descartar;
- revisar rangos paramétricos;
- repetir WFM solo si la configuración estaba incorrecta;
- no relajar threshold para rescatar.

---

# 23. Lenguaje obligatorio para alumnos

Separar:

```text
DATO SQX
CÁLCULO REPRODUCIDO
INFERENCIA
DECISIÓN
```

Ejemplo:

```text
DATO SQX:
WF Stability = 30.47%

CÁLCULO REPRODUCIDO:
mean OOS / mean IS = 30.47%

INFERENCIA:
hay fuerte degradación IS→OOS.

DECISIÓN:
falla el gate de 50%.
```

Nunca presentar una inferencia como si fuera un dato almacenado.

---

# 24. Errores prohibidos

La skill nunca debe:

1. Usar el Ret/DD de la estrategia original para calcular WF Stability.
2. Confundir WF Final Result con WF Stability.
3. Incluir el future period en el cálculo histórico.
4. Analizar solo la mejor celda.
5. Ignorar los vecinos de la celda verde.
6. Declarar robustez por Parameter Stability solamente.
7. Declarar fracaso por una sola ventana mala sin mirar la matriz.
8. Bajar el threshold después de ver resultados para rescatar la estrategia.
9. Ignorar el número de trades OOS.
10. Inventar métricas que el `.sqx` no permite recuperar.
11. Prometer causalidad de régimen; solo sugerir dependencia.
12. Contradecir el PASS/FAIL configurado sin explicar que se está usando otro criterio.
13. Recomendar parámetros del "best cell" automáticamente para live.
14. Confundir WFM con SPP.
15. Evaluar portafolio solo con WFM.

---

# 25. Checklist final

```text
[ ] .sqx abierto como contenedor.
[ ] settings.xml leído.
[ ] Main separado de WF.
[ ] MatrixResult reconstruida.
[ ] Total de celdas correcto.
[ ] Conditions extraídas.
[ ] thresholdPct identificado.
[ ] robCombRows/Cols/Min identificados.
[ ] futurePeriod excluido.
[ ] WF Final matrix reportada.
[ ] WF Stability matrix reportada.
[ ] Parameter Stability reportada.
[ ] Pass/fail matrix reportada.
[ ] Runs IS/OOS de celdas relevantes analizados.
[ ] Sample size revisado.
[ ] Parámetros revisados.
[ ] Plateau revisada.
[ ] Sensitivity map solo diagnóstico.
[ ] Resultado SQX respetado.
[ ] Veredicto binario emitido.
[ ] Siguiente acción indicada.
```

---

# 26. Prompt corto de activación

```text
Activa SQX WFM DEEP ANALYZER V1. Analiza profundamente el archivo .sqx adjunto. Extrae directamente la Walk-Forward Matrix, sus condiciones, todas las celdas, WF Final Result, WF Stability, Parameter Stability y los runs IS/OOS. Reproduce matemáticamente WF Stability cuando sea posible, excluye future periods, analiza meseta/vecindad y parámetros, explica por qué SQX marca PASS o FAIL y emite un veredicto binario sin cambiar los thresholds después de ver el resultado.
```

---

# 27. Prompt completo para alumno

```text
ACTIVA: SQX WFM DEEP ANALYZER V1 — MODO COMPLETO

Voy a adjuntar una estrategia de StrategyQuant X en formato .sqx.

OBJETIVO
Quiero entender a profundidad la Walk-Forward Matrix y validar si el resultado que muestra SQX está correctamente interpretado.

INSTRUCCIONES
1. Usa el .sqx como fuente primaria.
2. Abre su estructura interna y lee settings.xml.
3. Identifica estrategia, símbolo, timeframe y rango.
4. Localiza WalkForwardResult / MatrixResult.
5. Reconstruye todos los valores de Runs y OOS% y el número total de celdas.
6. Extrae exactamente las condiciones WFM almacenadas:
   - métricas;
   - comparadores;
   - thresholds;
   - robustness threshold;
   - tamaño del grupo;
   - mínimo de celdas requerido.
7. Separa claramente:
   - estrategia original;
   - WF Final Result;
   - WF Stability;
   - Parameter Stability.
8. No uses las métricas de la estrategia original para calcular WF Stability.
9. Para Ret/DD, reproduce WF Stability desde los runs IS/OOS y verifica que coincida con SQX.
10. Excluye cualquier WalkForwardPeriod marcado futurePeriod=true.
11. Construye la matriz completa de:
   - WF Final Result;
   - WF Stability;
   - Parameter Stability;
   - PASS/FAIL.
12. Calcula media, mediana, mínimo, máximo y porcentaje de celdas que superan cada threshold.
13. Analiza las celdas verdes y sus vecinos; determina si existe una meseta robusta o puntos aislados.
14. Reproduce el criterio robCombRows × robCombCols / robMinComb.
15. Analiza los runs IS/OOS de:
   - la celda seleccionada;
   - las celdas que pasan;
   - las mejores y peores celdas.
16. Reporta # trades OOS y advierte si la muestra es débil.
17. Extrae los parámetros elegidos en cada run y detecta:
   - boundary hits;
   - concentración en valores;
   - saltos paramétricos;
   - estabilidad paramétrica.
18. Si NetProfit por run está disponible, analiza concentración de beneficio y % profitable runs.
19. Haz un sensitivity map de thresholds solo para diagnóstico, sin cambiar el gate oficial para rescatar la estrategia.
20. Clasifica cualquier fallo:
   FAIL_ABSOLUTE_PERFORMANCE,
   FAIL_WF_STABILITY,
   FAIL_NO_PLATEAU,
   FAIL_TOO_FEW_PASSING_CELLS,
   FAIL_SAMPLE_SIZE,
   FAIL_PARAMETER_BOUNDARY,
   FAIL_PARAMETER_INSTABILITY,
   FAIL_PROFIT_CONCENTRATION,
   FAIL_REGIME_DEPENDENCE_SUSPECTED,
   FAIL_FILTER_CONFIGURATION.
21. Explica en lenguaje sencillo por qué SQX muestra lo que muestra.
22. Separa DATO SQX, CÁLCULO REPRODUCIDO, INFERENCIA y DECISIÓN.
23. Emite resultado:
   APROBADA WFM o DESCARTADA WFM.
24. No cambies los thresholds después de ver los resultados.
25. Termina con la siguiente acción recomendada dentro del pipeline de robustez.
```

---

# 28. Estado

```text
SQX WFM DEEP ANALYZER V1.0
Input principal: .sqx
Output: auditoría WFM profunda + PASS/FAIL
Uso: formación, research, validación pre-MT5
```
