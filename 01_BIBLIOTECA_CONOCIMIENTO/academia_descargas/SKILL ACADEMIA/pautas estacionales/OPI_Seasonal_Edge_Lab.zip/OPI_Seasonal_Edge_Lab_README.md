# OPI Seasonal Edge Lab

Paquete reutilizable para alumnos que quieran investigar pautas estacionales de trading con un flujo cuantitativo ordenado.

## Archivos

- `OPI_Seasonal_Edge_Lab_SKILL.md`: especificación completa del skill.
- `OPI_Seasonal_Edge_Lab_PROMPT.txt`: prompt para iniciar una investigación.
- `OPI_Seasonal_Edge_Lab_README.md`: instrucciones de uso.

## Uso recomendado

1. Abrir un chat nuevo.
2. Adjuntar la data histórica del activo.
3. Adjuntar o pegar el contenido de `OPI_Seasonal_Edge_Lab_SKILL.md`.
4. Pegar el prompt de invocación.
5. Dejar que el proceso termine antes de empezar a modificar parámetros.
6. Si se genera un EA, validarlo después en MetaTrader 5 y comparar el reporte con las operaciones esperadas.

## Filosofía

El skill está diseñado para rechazar falsos edges. No existe obligación de producir un EA en cada dataset.
