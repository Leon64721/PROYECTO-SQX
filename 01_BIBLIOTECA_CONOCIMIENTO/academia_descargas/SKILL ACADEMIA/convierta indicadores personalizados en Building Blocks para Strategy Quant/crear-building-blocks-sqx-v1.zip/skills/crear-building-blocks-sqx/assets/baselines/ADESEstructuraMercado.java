package SQ.Blocks.Indicators.ADESEstructuraMercado;

import com.strategyquant.lib.*;
import com.strategyquant.datalib.*;
import com.strategyquant.tradinglib.*;

import SQ.Internal.IndicatorBlock;

/**
 * Causal StrategyQuant port of the actionable core of Estructura_mercado.mq4.
 *
 * The original chart-object labels, text objects and decorative buffers are not
 * used by the Builder and are intentionally omitted. Structural events are
 * emitted on the bar on which they become knowable, avoiding historical
 * backfilling in strategy rules.
 *
 * Output codes:
 * Direction:  1 bullish, -1 bearish, 0 undefined
 * Event:      1 bullish BOS, 2 bullish CHOCH,
 *            -1 bearish BOS, -2 bearish CHOCH, 0 none
 * Pivot:      44 HH, 41 lower high, 14 higher low, 11 LL, 0 none
 * Swing:      1 confirmed swing high, -1 confirmed swing low, 2 both, 0 none
 * Imbalance:  1 bullish imbalance, -1 bearish imbalance, 0 none
 */
@BuildingBlock(
    name = "(ADES) Estructura de mercado",
    display = "ADES Estructura Mercado.#Line#[#Shift#]",
    returnType = ReturnTypes.Number
)
@Help("Causal market-structure engine: HH/LH/HL/LL, BOS, CHOCH, swings, imbalances, Fibonacci and Heikin Ashi.")
public class ADESEstructuraMercado extends IndicatorBlock {

    @Parameter
    public ChartData Chart;

    @Output(name = "Direction")
    public DataSeries Direction;

    @Output(name = "Event")
    public DataSeries Event;

    @Output(name = "Pivot")
    public DataSeries Pivot;

    @Output(name = "Swing")
    public DataSeries Swing;

    @Output(name = "Imbalance")
    public DataSeries Imbalance;

    @Output(name = "BOSLevel")
    public DataSeries BOSLevel;

    @Output(name = "CHOCHLevel")
    public DataSeries CHOCHLevel;

    @Output(name = "Fibo50")
    public DataSeries Fibo50;

    @Output(name = "Fibo618")
    public DataSeries Fibo618;

    @Output(name = "Fibo764")
    public DataSeries Fibo764;

    @Output(name = "HAOpen")
    public DataSeries HAOpen;

    @Output(name = "HAClose")
    public DataSeries HAClose;

    @Output(name = "HAHigh")
    public DataSeries HAHigh;

    @Output(name = "HALow")
    public DataSeries HALow;

    private static final double INF = Double.POSITIVE_INFINITY;
    private static final double EPS = 1.0e-12;

    private double ghostHigh;
    private double fixedHigh1;
    private double fixedHigh2;
    private double fixedHigh3;

    private int ghostHighBar;
    private int fixedHighBar1;
    private int fixedHighBar2;
    private int fixedHighBar3;

    private double ghostLow;
    private double fixedLow1;
    private double fixedLow2;
    private double fixedLow3;

    private int ghostLowBar;
    private int fixedLowBar1;
    private int fixedLowBar2;
    private int fixedLowBar3;

    private boolean highBrokenByBody;
    private boolean lowBrokenByBody;

    private int lastHighPivotType;
    private int lastLowPivotType;
    private int lastPivotType;

    private boolean hasSwingHighPattern;
    private boolean hasSwingLowPattern;

    private double previousHAOpen;
    private double previousHAClose;
    private int ha0;
    private int ha1;
    private int ha2;
    private int ha3;

    private double activeBOS;
    private double activeCHOCH;
    private int activeDirection;

    //------------------------------------------------------------------------

    private void resetState() {
        ghostHigh = 0.0;
        fixedHigh1 = 0.0;
        fixedHigh2 = 0.0;
        fixedHigh3 = 0.0;

        ghostHighBar = -1;
        fixedHighBar1 = -1;
        fixedHighBar2 = -1;
        fixedHighBar3 = -1;

        ghostLow = INF;
        fixedLow1 = INF;
        fixedLow2 = INF;
        fixedLow3 = INF;

        ghostLowBar = -1;
        fixedLowBar1 = -1;
        fixedLowBar2 = -1;
        fixedLowBar3 = -1;

        highBrokenByBody = false;
        lowBrokenByBody = false;

        lastHighPivotType = 0;
        lastLowPivotType = 0;
        lastPivotType = 0;

        hasSwingHighPattern = false;
        hasSwingLowPattern = false;

        previousHAOpen = 0.0;
        previousHAClose = 0.0;
        ha0 = 0;
        ha1 = 0;
        ha2 = 0;
        ha3 = 0;

        activeBOS = 0.0;
        activeCHOCH = 0.0;
        activeDirection = 0;
    }

    private boolean isFinite(double value) {
        return !Double.isNaN(value) && !Double.isInfinite(value);
    }

    private boolean greater(double left, double right) {
        return left > right + EPS;
    }

    private boolean lower(double left, double right) {
        return left < right - EPS;
    }

    private boolean equal(double left, double right) {
        return Math.abs(left - right) <= EPS;
    }

    private int updateHeikinAshi() throws com.strategyquant.datalib.TradingException {
        double haOpen = (previousHAOpen + previousHAClose) / 2.0;
        double haClose = (
            Chart.Open.get(0)
            + Chart.High.get(0)
            + Chart.Low.get(0)
            + Chart.Close.get(0)
        ) / 4.0;

        double haHigh = Math.max(Chart.High.get(0), Math.max(haOpen, haClose));
        double haLow = Math.min(Chart.Low.get(0), Math.min(haOpen, haClose));

        previousHAOpen = haOpen;
        previousHAClose = haClose;

        ha3 = ha2;
        ha2 = ha1;
        ha1 = ha0;
        ha0 = haClose > haOpen ? 1 : -1;

        HAOpen.set(0, haOpen);
        HAClose.set(0, haClose);
        HAHigh.set(0, haHigh);
        HALow.set(0, haLow);

        if (ha3 == 1 && ha2 == 1 && ha1 == -1 && ha0 == -1) {
            return 1;
        }
        if (ha3 == -1 && ha2 == -1 && ha1 == 1 && ha0 == 1) {
            return -1;
        }
        return 0;
    }

    private int confirmedSwingCode() throws com.strategyquant.datalib.TradingException {
        if (CurrentBar < 2) {
            return 0;
        }

        boolean swingHigh =
            Chart.High.get(1) > Chart.High.get(2)
            && Chart.High.get(1) >= Chart.High.get(0);

        boolean swingLow =
            Chart.Low.get(1) < Chart.Low.get(2)
            && Chart.Low.get(1) <= Chart.Low.get(0);

        if (swingHigh) {
            double value = Chart.High.get(1);
            if (value >= ghostHigh) {
                ghostHigh = value;
                ghostHighBar = CurrentBar - 1;
            }
        }

        if (swingLow) {
            double value = Chart.Low.get(1);
            if (value <= ghostLow) {
                ghostLow = value;
                ghostLowBar = CurrentBar - 1;
            }
        }

        if (swingHigh && swingLow) {
            return 2;
        }
        if (swingHigh) {
            return 1;
        }
        if (swingLow) {
            return -1;
        }
        return 0;
    }

    private void detectBodyBreaks() throws com.strategyquant.datalib.TradingException {
        if (CurrentBar < 1) {
            return;
        }

        if (!highBrokenByBody) {
            double priorBodyHigh = Math.max(Chart.Close.get(1), Chart.Open.get(1));
            if (priorBodyHigh > fixedHigh1) {
                highBrokenByBody = true;
                ghostHigh = Chart.High.get(1);
                ghostHighBar = CurrentBar - 1;

                if (Chart.High.get(0) > Chart.High.get(1)) {
                    ghostHigh = Chart.High.get(0);
                    ghostHighBar = CurrentBar;
                }
                hasSwingHighPattern = false;
            }
        }

        if (!lowBrokenByBody) {
            double priorBodyLow = Math.min(Chart.Close.get(1), Chart.Open.get(1));
            if (priorBodyLow < fixedLow1) {
                lowBrokenByBody = true;
                ghostLow = Chart.Low.get(1);
                ghostLowBar = CurrentBar - 1;

                if (Chart.Low.get(0) < Chart.Low.get(1)) {
                    ghostLow = Chart.Low.get(0);
                    ghostLowBar = CurrentBar;
                }
                hasSwingLowPattern = false;
            }
        }
    }

    private int reviewMaximumOrMinimum() {
        int hasMaximum = 0;
        int hasMinimum = 0;

        if (highBrokenByBody) {
            if (hasSwingLowPattern && isFinite(ghostLow)) {
                if (fixedHighBar1 >= fixedLowBar1 && ghostLowBar > fixedHighBar1) {
                    hasMinimum = 1;
                }
            }

            if (fixedLowBar1 >= fixedHighBar1) {
                if (ghostHighBar > fixedLowBar1) {
                    hasMaximum = 1;
                }
            } else if (fixedHighBar1 >= fixedLowBar1) {
                if (ghostHighBar > fixedHighBar1 && ghostHigh > fixedHigh1) {
                    hasMaximum = 1;
                }
            }

            if (hasMaximum == 1 && hasMinimum != 1 && isFinite(ghostLow) && ghostLow != 0.0) {
                if (ghostLow <= fixedLow1) {
                    if (ghostLowBar > fixedLowBar1 && ghostLowBar < ghostHighBar) {
                        hasMinimum = 1;
                    }
                }
            }
        }

        if (lowBrokenByBody) {
            if (hasSwingHighPattern && ghostHigh != 0.0) {
                if (fixedLowBar1 >= fixedHighBar1 && ghostHighBar > fixedLowBar1) {
                    hasMaximum = 1;
                }
            }

            if (fixedHighBar1 >= fixedLowBar1) {
                if (ghostLowBar > fixedHighBar1) {
                    hasMinimum = 1;
                }
            } else if (fixedLowBar1 >= fixedHighBar1) {
                if (ghostLowBar > fixedLowBar1 && ghostLow < fixedLow1) {
                    hasMinimum = 1;
                }
            }

            if (hasMinimum == 1 && hasMaximum != 1 && ghostHigh != 0.0) {
                if (ghostHigh > fixedHigh1) {
                    if (ghostHighBar > fixedHighBar1 && ghostHighBar < ghostLowBar) {
                        hasMaximum = 1;
                    }
                }
            }
        }

        if (!highBrokenByBody) {
            if (lastPivotType == 44 && !hasSwingLowPattern && ghostHigh > fixedHigh1) {
                hasMaximum = 1;
            }
        }

        if (!lowBrokenByBody) {
            if (lastPivotType == 11 && !hasSwingHighPattern && ghostLow < fixedLow1) {
                hasMinimum = 1;
            }
        }

        if (hasMaximum == 1 && hasMinimum == 1) {
            return 2;
        }
        if (hasMaximum == 1) {
            return 1;
        }
        if (hasMinimum == 1) {
            return -1;
        }
        return 0;
    }

    private int fixMaximum() {
        if (ghostHighBar < 0) {
            return 0;
        }

        int code;
        if (greater(ghostHigh, fixedHigh1)) {
            code = 44; // Higher High
        } else if (lower(ghostHigh, fixedHigh1)) {
            code = 41; // Lower High
        } else if (ghostHighBar > fixedHighBar1 && lastHighPivotType != 0) {
            code = lastHighPivotType; // Equal high inherits previous class
            fixedHighBar1 = ghostHighBar;
            lastPivotType = code;
            return code;
        } else {
            return 0;
        }

        fixedHigh3 = fixedHigh2;
        fixedHigh2 = fixedHigh1;
        fixedHigh1 = ghostHigh;

        fixedHighBar3 = fixedHighBar2;
        fixedHighBar2 = fixedHighBar1;
        fixedHighBar1 = ghostHighBar;

        lastHighPivotType = code;
        lastPivotType = code;
        return code;
    }

    private int fixMinimum() {
        if (ghostLowBar < 0 || !isFinite(ghostLow)) {
            return 0;
        }

        int code;
        if (greater(ghostLow, fixedLow1)) {
            code = 14; // Higher Low
        } else if (lower(ghostLow, fixedLow1)) {
            code = 11; // Lower Low
        } else if (ghostLowBar > fixedLowBar1 && lastLowPivotType != 0) {
            code = lastLowPivotType; // Equal low inherits previous class
            fixedLowBar1 = ghostLowBar;
            lastPivotType = code;
            return code;
        } else {
            return 0;
        }

        fixedLow3 = fixedLow2;
        fixedLow2 = fixedLow1;
        fixedLow1 = ghostLow;

        fixedLowBar3 = fixedLowBar2;
        fixedLowBar2 = fixedLowBar1;
        fixedLowBar1 = ghostLowBar;

        lastLowPivotType = code;
        lastPivotType = code;
        return code;
    }

    private int processFixedPivots(int review) {
        int pivotEvent = 0;

        if (review == 1 || review == 2) {
            int highCode = fixMaximum();
            if (highCode != 0) {
                pivotEvent = highCode;
            }

            highBrokenByBody = false;
            lowBrokenByBody = false;

            if (review == 1) {
                hasSwingLowPattern = false;
                ghostLow = INF;
                ghostLowBar = -1;
            }
        }

        if (review == -1 || review == 2) {
            int lowCode = fixMinimum();
            if (lowCode != 0) {
                pivotEvent = lowCode;
            }

            lowBrokenByBody = false;
            highBrokenByBody = false;

            if (fixedLowBar1 != fixedHighBar1) {
                hasSwingHighPattern = false;
                ghostHigh = 0.0;
                ghostHighBar = -1;

                if (review == 2) {
                    hasSwingLowPattern = false;
                    ghostLow = INF;
                    ghostLowBar = -1;
                }
            } else {
                hasSwingHighPattern = false;
                if (review == 2) {
                    hasSwingLowPattern = false;
                }
            }
        }

        return pivotEvent;
    }

    private void updateStructureLevels() throws com.strategyquant.datalib.TradingException {
        boolean updated = false;
        double bos = activeBOS;
        double choch = activeCHOCH;

        if (lastHighPivotType == 44 && fixedHighBar1 > fixedLowBar1 && isFinite(fixedLow1)) {
            bos = fixedHigh1;
            choch = fixedLow1;
            updated = true;
        } else if (lastLowPivotType == 11 && fixedLowBar1 > fixedHighBar1 && fixedHigh1 != 0.0) {
            bos = fixedLow1;
            choch = fixedHigh1;
            updated = true;
        } else if (
            lastHighPivotType == 44
            && fixedHighBar1 == fixedLowBar1
            && lastLowPivotType != 11
            && isFinite(fixedLow1)
        ) {
            bos = fixedHigh1;
            choch = fixedLow1;
            updated = true;
        } else if (
            lastLowPivotType == 11
            && fixedLowBar1 == fixedHighBar1
            && lastHighPivotType != 44
            && fixedHigh1 != 0.0
        ) {
            bos = fixedLow1;
            choch = fixedHigh1;
            updated = true;
        } else if (
            lastHighPivotType == 44
            && lastLowPivotType == 11
            && fixedHighBar1 == fixedLowBar1
            && fixedHighBar1 >= 0
        ) {
            int offset = Math.max(0, CurrentBar - fixedHighBar1);
            double commonClose = Chart.Close.get(offset);
            double commonOpen = Chart.Open.get(offset);

            double priorBOS = CurrentBar > 0 ? BOSLevel.get(1) : 0.0;
            double priorCHOCH = CurrentBar > 0 ? CHOCHLevel.get(1) : 0.0;

            boolean bullish;
            if (priorBOS != 0.0 || priorCHOCH != 0.0) {
                if (commonClose > Math.max(priorBOS, priorCHOCH)) {
                    bullish = true;
                } else if (commonClose < Math.min(priorBOS, priorCHOCH)) {
                    bullish = false;
                } else {
                    bullish = commonClose >= commonOpen;
                }
            } else {
                bullish = commonClose >= commonOpen;
            }

            if (bullish) {
                bos = fixedHigh1;
                choch = fixedLow1;
            } else {
                bos = fixedLow1;
                choch = fixedHigh1;
            }
            updated = true;
        }

        if (updated) {
            activeBOS = bos;
            activeCHOCH = choch;
            if (activeBOS > activeCHOCH) {
                activeDirection = 1;
            } else if (activeBOS < activeCHOCH) {
                activeDirection = -1;
            } else {
                activeDirection = 0;
            }
        }
    }

    private int detectStructureEvent() throws com.strategyquant.datalib.TradingException {
        if (CurrentBar < 1 || activeDirection == 0 || activeBOS == 0.0 || activeCHOCH == 0.0) {
            return 0;
        }

        double currentClose = Chart.Close.get(0);
        double priorClose = Chart.Close.get(1);

        double priorBOS = BOSLevel.get(1);
        double priorCHOCH = CHOCHLevel.get(1);

        if (priorBOS == 0.0) {
            priorBOS = activeBOS;
        }
        if (priorCHOCH == 0.0) {
            priorCHOCH = activeCHOCH;
        }

        if (activeDirection > 0) {
            if (priorClose <= priorBOS && currentClose > activeBOS) {
                return 1; // Bullish BOS
            }
            if (priorClose >= priorCHOCH && currentClose < activeCHOCH) {
                return -2; // Bearish CHOCH
            }
        } else {
            if (priorClose >= priorBOS && currentClose < activeBOS) {
                return -1; // Bearish BOS
            }
            if (priorClose <= priorCHOCH && currentClose > activeCHOCH) {
                return 2; // Bullish CHOCH
            }
        }

        return 0;
    }

    private int detectImbalance() throws com.strategyquant.datalib.TradingException {
        if (CurrentBar < 2) {
            return 0;
        }

        boolean oldBarIsNotDoji = Chart.Open.get(2) != Chart.Close.get(2);
        if (!oldBarIsNotDoji) {
            return 0;
        }

        if (Chart.Low.get(0) > Chart.High.get(2)) {
            return 1;
        }
        if (Chart.High.get(0) < Chart.Low.get(2)) {
            return -1;
        }
        return 0;
    }

    private void setLevelOutputs() throws com.strategyquant.datalib.TradingException {
        BOSLevel.set(0, activeBOS);
        CHOCHLevel.set(0, activeCHOCH);
        Direction.set(0, activeDirection);

        if (activeDirection == 0 || activeBOS == 0.0 || activeCHOCH == 0.0) {
            Fibo50.set(0, 0.0);
            Fibo618.set(0, 0.0);
            Fibo764.set(0, 0.0);
            return;
        }

        if (activeBOS > activeCHOCH) {
            double range = activeBOS - activeCHOCH;
            Fibo50.set(0, activeBOS - range * 0.500);
            Fibo618.set(0, activeBOS - range * 0.618);
            Fibo764.set(0, activeBOS - range * 0.764);
        } else {
            double range = activeCHOCH - activeBOS;
            Fibo50.set(0, activeBOS + range * 0.500);
            Fibo618.set(0, activeBOS + range * 0.618);
            Fibo764.set(0, activeBOS + range * 0.764);
        }
    }

    //------------------------------------------------------------------------

    @Override
    protected void OnBarUpdate() throws com.strategyquant.datalib.TradingException {
        if (CurrentBar == 0) {
            resetState();
        }

        Pivot.set(0, 0.0);
        Swing.set(0, 0.0);
        Event.set(0, 0.0);
        Imbalance.set(0, 0.0);

        int haFormation = updateHeikinAshi();

        if (CurrentBar == 0) {
            setLevelOutputs();
            return;
        }

        int swingCode = confirmedSwingCode();
        Swing.set(0, swingCode);

        if (haFormation == 1) {
            hasSwingHighPattern = true;
        } else if (haFormation == -1) {
            hasSwingLowPattern = true;
        }

        detectBodyBreaks();

        int review = reviewMaximumOrMinimum();
        int pivotEvent = processFixedPivots(review);
        Pivot.set(0, pivotEvent);

        updateStructureLevels();
        setLevelOutputs();

        Event.set(0, detectStructureEvent());
        Imbalance.set(0, detectImbalance());
    }
}
