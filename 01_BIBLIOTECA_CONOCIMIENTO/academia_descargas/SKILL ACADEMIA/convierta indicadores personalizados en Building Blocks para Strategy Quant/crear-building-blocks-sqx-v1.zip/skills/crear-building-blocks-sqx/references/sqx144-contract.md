# Contrato técnico para SQX Build 144.2953

## 1. Decisión de arquitectura

### XML compuesto sin Java

Úsalo cuando la regla pueda expresarse exactamente con precios, indicadores, comparadores y operadores existentes en SQX. Es la opción preferida para reglas booleanas simples porque reduce dependencias de compilación.

### Java + XML

Úsalo cuando el indicador tenga estado persistente, recursión, varios buffers, pivots confirmados, estructuras discretas, lógica no disponible en bloques nativos o una salida que deba reutilizarse en varios bloques.

No portes objetos gráficos, etiquetas o alertas que no participen en la decisión. Sí porta cualquier estado que cambie una salida operativa.

## 2. Estructura de archivos

Para un indicador Java llamado `MiIndicador`:

```text
user/extend/Snippets/SQ/Blocks/Indicators/MiIndicador/MiIndicador.java
custom_blocks/ADES_MiIndicador_BuildingBlocks_SQX144.xml
templates/MT5/MiIndicador.tpl
CONTRATO_SENAL.md
VALIDACION.txt
```

El package Java debe concordar con la ruta:

```java
package SQ.Blocks.Indicators.MiIndicador;
```

Usa las anotaciones y tipos que existan en Build 144.2953. El patrón validado emplea `@BuildingBlock`, `@Help`, `@Parameter`, `@Output`, `ChartData`, `DataSeries` e `IndicatorBlock`. Para excepciones de acceso a datos usa la clase real `com.strategyquant.datalib.TradingException`, importada o totalmente calificada.

## 3. Contrato XML

- Raíz: `<CustomBlocks>`.
- Cada bloque superior es un `<Item>` con `category="ADES"`, clave única `CBlock_<Nombre>`, `type`, `returnType`, `name`, `display`, `Contents` y parámetros externos cuando correspondan.
- `categoryType="Custom blocks"`, `strategyType="Standard"`, `status="0"` y `action="add"` son el patrón base de los archivos validados.
- Un par BUY/SELL realmente simétrico referencia sus claves mediante `oppositeBlockKey`. Un bloque sin opuesto usa `CBlock_null`.
- Los placeholders usados por Items internos deben declararse como Params externos del bloque. Ejemplos: `#Chart1#`, `#Int2#`.
- Un indicador Java con varias salidas expone `#Line#` mediante un Param combo cuyos índices coinciden exactamente con los `@Output` del Java.
- El `mI` del Item `customSnippet="true"` debe coincidir con el snippet/indicador instalado.
- Mantén nombres cortos, estables y sin sufijos accidentales que SQX pueda reinterpretar.

## 4. Causalidad

El contrato debe responder, para cada señal:

1. ¿Qué barras necesita?
2. ¿En qué barra se conoce definitivamente?
3. ¿En qué barra se publica?
4. ¿Puede cambiar después de publicada?

Regla del proyecto: el Builder consume por defecto la última barra cerrada (`Shift 1`). Para pivots que requieren barras posteriores, publica el evento en la barra de confirmación. Nunca marque retrospectivamente la barra del extremo como si la señal hubiera sido conocida allí.

Los cálculos recursivos deben definir warm-up, estado inicial y comportamiento ante datos insuficientes. Un valor `0` o `NaN` debe tener un significado explícito; no lo uses indistintamente como señal y como ausencia de datos.

## 5. Plantillas de exportación

Incluye plantillas solo para las plataformas solicitadas. El patrón MT5 validado para una salida múltiple fue:

```text
iCustom(<@printInput block />, "MiIndicador", <@printParam block "#Line#" />, <@printShift block shift />)
```

La firma real puede variar con los parámetros del indicador. Debe conservar el orden de inputs y mapear la línea/salida correcta. No declares paridad de exportación hasta inspeccionar un EA generado por SQX.

## 6. Gates de aceptación

| Gate | Evidencia | Resultado requerido |
| --- | --- | --- |
| G0 Semántica | Contrato contra el fuente original | Todas las salidas y parámetros relevantes tienen definición inequívoca |
| G1 Causalidad | Tabla barra necesaria/conocida/publicada | Sin look-ahead ni backfill comercial |
| G2 Estructura | Validador local XML y revisión Java | XML bien formado, claves y refs coherentes, categoría ADES |
| G3 Dependencias | Revisión de package, imports, outputs y TPL | Ninguna API o ruta inventada |
| G4 SQX real | CodeEditor Compile all + importación | Cero errores y bloques visibles bajo ADES |
| G5 Exportación | EA MT4/MT5 generado por SQX | Lógica, parámetros, shifts y líneas preservados |
| G6 Paridad | Señales comparadas en muestra común | Diferencias explicadas o cero discrepancias según el contrato |

Si no hay acceso a la instalación real de SQX, G4–G6 quedan marcados `PENDIENTE`; nunca se reportan como aprobados por inferencia.

