# Maestros históricos validados

## D1A — breakout Highest exacto

La regla maestra quedó congelada como:

```text
Close[1] > Highest(High, N)[2]
AND
Close[2] <= Highest(High, N)[3]
```

El archivo histórico es `D1A_Exact_Breakout_Highest_High_V2_SQX144.xml`. Fue verificado mediante EAs exportados. Las nuevas variantes deben mantener la categoría `ADES`, aunque el archivo histórico preceda esa regla permanente.

## `50_20_BO`

Bloque long-only validado bajo categoría `ADES`:

```text
Close[1] > Highest(High, Highest Period)[2]
AND Close[2] <= Highest(High, Highest Period)[3]
AND EMA(Close, 50)[1] > EMA(Close, 200)[1]
AND Close[1] > EMA(Close, 200)[1]
```

Único parámetro optimizable:

- `Highest Period`: default 20, mínimo 14, máximo 45, paso 1.

Las EMA 50/200 y los shifts son constantes de la hipótesis, no parámetros libres.

## `ADESEstructuraMercado`

Arquitectura validada: indicador Java causal multisalida + XML con 14 condiciones + plantilla MT5.

Salidas Java:

| Línea | Salida | Códigos relevantes |
| ---: | --- | --- |
| 0 | Direction | 1 alcista, -1 bajista, 0 indefinida |
| 1 | Event | 1 BOS alcista, 2 CHOCH alcista, -1 BOS bajista, -2 CHOCH bajista |
| 2 | Pivot | 44 HH, 41 LH, 14 HL, 11 LL |
| 3 | Swing | 1 swing high, -1 swing low, 2 ambos |
| 4 | Imbalance | 1 alcista, -1 bajista |
| 5–9 | BOSLevel, CHOCHLevel, Fibo50, Fibo618, Fibo764 | niveles numéricos |
| 10–13 | HAOpen, HAClose, HAHigh, HALow | precios Heikin Ashi internos |

Bloques incluidos:

- `EM_BullishStructure` / `EM_BearishStructure`
- `EM_BullishBOS` / `EM_BearishBOS`
- `EM_BullishCHOCH` / `EM_BearishCHOCH`
- `EM_HigherHigh` / `EM_LowerHigh`
- `EM_HigherLow` / `EM_LowerLow`
- `EM_SwingHigh` / `EM_SwingLow`
- `EM_BullishImbalance` / `EM_BearishImbalance`

Lecciones de integración:

- La excepción correcta es `com.strategyquant.datalib.TradingException`; no asumir una clase homónima en otro paquete.
- El package Java, la ruta de carpetas, el nombre del snippet, `mI` y el nombre usado por la plantilla deben coincidir exactamente.
- Los eventos se publican al confirmarse y los bloques comerciales leen Shift 1.
- Los objetos gráficos del indicador MT4 no se portaron porque no afectaban la lógica de decisión.
- Una validación sintáctica local no sustituye `Compile all`, importación y exportación real en la instalación del usuario.

## Activos incluidos en la skill

`assets/baselines/` contiene las versiones maestras recuperadas:

- `SQX144_CustomBlock_Factory_v4_ADES.zip`
- `ADES_EstructuraMercado_SQX144_v4_IMPORTS_FIX.zip`
- los XML de D1A, `50_20_BO` y `ADESEstructuraMercado`
- el Java y la plantilla MT5 de `ADESEstructuraMercado`

Úsalos como contrato estructural y casos de regresión, no como lógica predeterminada para indicadores nuevos.

