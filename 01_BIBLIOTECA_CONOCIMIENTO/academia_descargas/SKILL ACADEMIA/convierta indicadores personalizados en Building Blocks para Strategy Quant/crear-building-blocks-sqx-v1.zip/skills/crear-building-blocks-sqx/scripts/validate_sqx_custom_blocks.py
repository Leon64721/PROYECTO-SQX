#!/usr/bin/env python3
"""Static checks for StrategyQuant X 144 custom-block XML files."""

from __future__ import annotations

import argparse
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path


PLACEHOLDER = re.compile(r"^#[A-Za-z][A-Za-z0-9_]*#$")


def validate(path: Path) -> tuple[list[str], list[str], list[str]]:
    passed: list[str] = []
    warnings: list[str] = []
    failures: list[str] = []

    try:
        root = ET.parse(path).getroot()
    except (OSError, ET.ParseError) as exc:
        return passed, warnings, [f"XML unreadable: {exc}"]

    if root.tag != "CustomBlocks":
        failures.append(f"root must be CustomBlocks, got {root.tag!r}")
        return passed, warnings, failures
    passed.append("root CustomBlocks")

    blocks = root.findall("./Item")
    if not blocks:
        failures.append("no top-level Item blocks")
        return passed, warnings, failures
    passed.append(f"{len(blocks)} top-level block(s)")

    keys = [block.get("key", "") for block in blocks]
    names = [block.get("name", "") for block in blocks]
    for label, values in (("key", keys), ("name", names)):
        missing = [str(i + 1) for i, value in enumerate(values) if not value]
        duplicates = sorted({value for value in values if value and values.count(value) > 1})
        if missing:
            failures.append(f"missing {label} in block(s): {', '.join(missing)}")
        if duplicates:
            failures.append(f"duplicate {label}(s): {', '.join(duplicates)}")
    if not any("duplicate key" in item or "missing key" in item for item in failures):
        passed.append("unique non-empty block keys")
    if not any("duplicate name" in item or "missing name" in item for item in failures):
        passed.append("unique non-empty block names")

    known_keys = set(keys)
    for block in blocks:
        key = block.get("key", "<missing>")
        if not key.startswith("CBlock_"):
            failures.append(f"{key}: key must start with CBlock_")
        if block.get("category") != "ADES":
            failures.append(f"{key}: category must be ADES")
        if block.get("categoryType") != "Custom blocks":
            warnings.append(f"{key}: categoryType is not 'Custom blocks'")
        if block.get("strategyType") != "Standard":
            warnings.append(f"{key}: strategyType is not 'Standard'")
        if not block.get("type") or not block.get("returnType"):
            failures.append(f"{key}: missing type or returnType")
        if block.find("./Contents") is None:
            failures.append(f"{key}: missing Contents")

        opposite = block.get("oppositeBlockKey", "")
        if not opposite:
            warnings.append(f"{key}: oppositeBlockKey not declared")
        elif opposite != "CBlock_null" and opposite not in known_keys:
            failures.append(f"{key}: oppositeBlockKey {opposite!r} is not present")

        declared = {
            param.get("key", "")
            for param in block.findall("./Param")
            if param.get("key")
        }
        used: set[str] = set()
        for param in block.findall(".//Contents//Param"):
            value = (param.get("value") or "").strip()
            if PLACEHOLDER.fullmatch(value):
                used.add(value)
        undeclared = sorted(used - declared)
        if undeclared:
            failures.append(f"{key}: undeclared external param ref(s): {', '.join(undeclared)}")

        for item in block.findall(".//Contents//Item[@customSnippet='true']"):
            snippet = item.get("key", "<unnamed snippet>")
            if not item.get("mI"):
                failures.append(f"{key}/{snippet}: custom snippet missing mI")
            display = item.get("display", "")
            line_params = item.findall("./Param[@key='#Line#']")
            if "#Line#" in display and not line_params:
                failures.append(f"{key}/{snippet}: display uses #Line# without Param #Line#")
            for shift in item.findall("./Param[@paramType='shift']"):
                raw = (shift.text or shift.get("defaultValue") or "").strip()
                try:
                    shift_value = int(raw)
                except ValueError:
                    warnings.append(f"{key}/{snippet}: non-literal custom-snippet shift {raw!r}")
                else:
                    if shift_value < 1:
                        failures.append(f"{key}/{snippet}: causal block shift must be >= 1")

    if all(block.get("category") == "ADES" for block in blocks):
        passed.append("all blocks in ADES")
    if not any("oppositeBlockKey" in item and "not present" in item for item in failures):
        passed.append("opposite-block references resolve")
    if not any("undeclared external" in item for item in failures):
        passed.append("external parameter references resolve")

    return passed, warnings, failures


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Validate SQX 144 CustomBlocks XML with project invariants."
    )
    parser.add_argument("xml", nargs="+", type=Path)
    args = parser.parse_args()

    exit_code = 0
    for path in args.xml:
        passed, warnings, failures = validate(path)
        print(f"[{path}]")
        for item in passed:
            print(f"PASS: {item}")
        for item in warnings:
            print(f"WARN: {item}")
        for item in failures:
            print(f"FAIL: {item}")
        if failures:
            exit_code = 1
    return exit_code


if __name__ == "__main__":
    sys.exit(main())

