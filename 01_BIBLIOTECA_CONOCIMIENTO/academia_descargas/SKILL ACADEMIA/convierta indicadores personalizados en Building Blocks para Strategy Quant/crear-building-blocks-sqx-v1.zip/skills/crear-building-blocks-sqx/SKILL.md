---
name: crear-building-blocks-sqx
description: Convierte indicadores personalizados MT4/MT5 o reglas basadas en indicadores en Custom Building Blocks compatibles con StrategyQuant X Build 144.2953. Usar cuando el usuario adjunte un indicador, solicite portarlo a Java/XML/TPL de SQX, corregir su compilación o importación, comprobar causalidad o validar la paridad del bloque en un EA exportado. No usar para diseñar un Custom Project .cfx completo salvo que el trabajo dependa directamente de un bloque personalizado.
---

# SQX Custom Block Factory

Construye bloques reutilizables sin alterar la lógica económica del indicador original. La salida debe ser auditable, causal y utilizable por Builder, AlgoWizard y los exportadores solicitados.

## Invariantes del proyecto

- Apunta a **StrategyQuant X Build 144.2953**. No declares compatibilidad con otra build sin verificarla.
- Todos los Custom Building Blocks nuevos usan la categoría **`ADES`**.
- Conserva la semántica original antes de simplificarla. Separa núcleo operativo de objetos gráficos, alertas y decoración.
- Para discovery y backtest, usa por defecto información disponible al cierre de la barra y **Shift 1**. Un pivot se publica en la barra donde queda confirmado; no se retroescribe en la barra histórica del extremo.
- Si el usuario exige una señal intrabar o de barra 0, identifícala como variante distinta y explica su riesgo de repaint. No la mezcles con la versión causal.
- No inventes API, imports, buffers, códigos de salida ni rangos de optimización. Derívalos del indicador, de un bloque validado o de evidencia de la instalación del usuario.
- Expón solo parámetros que cambien una hipótesis real. Mantén fijas las constantes estructurales.

## Flujo de trabajo

1. Inspecciona completamente el indicador y cualquier archivo auxiliar. Documenta entradas, buffers/salidas, warm-up, dependencias entre barras, estados persistentes y puntos potenciales de repaint.
2. Escribe un **contrato de señal** antes de programar: nombre de cada salida, tipo, códigos, barra de publicación, parámetros y condición booleana de cada bloque.
3. Elige la arquitectura mínima:
   - XML compuesto con bloques nativos si SQX ya contiene todos los cálculos necesarios.
   - Indicador Java + XML si hay estado, buffers múltiples, recursión, lógica personalizada o cálculos no nativos.
   - Añade plantilla MT4/MT5 solo cuando el bloque deba sobrevivir a la exportación de código.
4. Implementa nombres y claves estables. Usa `CBlock_<Nombre>`; enlaza `oppositeBlockKey` solo para pares realmente simétricos y usa `CBlock_null` cuando no exista opuesto.
5. Lee [references/sqx144-contract.md](references/sqx144-contract.md) para rutas, contrato Java/XML/TPL y Gates de validación.
6. Ejecuta `scripts/validate_sqx_custom_blocks.py` sobre cada XML. Corrige todos los `FAIL`; revisa los `WARN` con criterio.
7. Entrega un paquete versionado con fuentes, XML, plantillas necesarias, contrato de señal e informe de validación. Incluye instrucciones cortas de instalación y las rutas exactas.
8. Distingue la validación local de la validación definitiva. La aceptación final requiere evidencia de **CodeEditor → Compile all**, importación en **AlgoWizard → Custom blocks**, reinicio cuando aplique y un EA exportado que contenga el bloque esperado.
9. Cuando el usuario devuelva errores o un EA exportado, corrige la misma versión del bloque; no cambies silenciosamente su lógica ni sus parámetros.

## Uso de las referencias maestras

- Lee [references/validated-blocks.md](references/validated-blocks.md) cuando el indicador se parezca a breakout/Highest, filtros EMA o estructura de mercado, o cuando haya errores de imports, `TradingException`, líneas de salida o exportación MT5.
- Reutiliza los archivos de `assets/baselines/` como patrones estructurales. No los copies a ciegas: conserva únicamente el esquema compatible y sustituye la lógica por la del indicador actual.

## Entregable mínimo

- `ADES_<Nombre>_BuildingBlocks_SQX144.xml`.
- Java en `user/extend/Snippets/SQ/Blocks/Indicators/<Nombre>/<Nombre>.java` cuando sea necesario.
- `.tpl` por plataforma de exportación cuando sea necesario.
- `CONTRATO_SENAL.md` con outputs, códigos, parámetros, shifts y causalidad.
- `VALIDACION.txt` con resultados locales y pruebas pendientes en la instalación real.
- ZIP final con versión explícita, por ejemplo `ADES_<Nombre>_SQX144_v1.zip`.
